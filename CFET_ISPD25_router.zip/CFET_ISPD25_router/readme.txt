要先把z3裝好 (https://github.com/Z3Prover/z3) 照上面把z3裝好
然後需要tcsh和設好z3路徑  (setenv LD_LIBRARY_PATH .....)

然後可以用generate_planning.sh讀一個cell placement的資料夾路徑，在planning資料夾下產生出cell routing結果

Ex: sh generate_planning.sh plmt/AND2x2_ASAP7_75t_SL

若要測試自己的placement結果，請遵照plmt file的格式

在tool的資料夾裡，可以化成圖檔，比較方便看