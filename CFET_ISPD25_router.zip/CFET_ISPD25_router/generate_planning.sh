DIRECTORY=$1
PLMTS=$(ls $1)
mkdir -p planning/${DIRECTORY##*/}
for PLMT_WITH_EXTENSION in $PLMTS
do
    PLMT_WITHOUT_EXTENSION=${PLMT_WITH_EXTENSION%.*}
    #echo $PLMT_WITHOUT_EXTENSION
    nohup ./build/router $DIRECTORY/$PLMT_WITHOUT_EXTENSION.plmt planning/${DIRECTORY##*/}/$PLMT_WITHOUT_EXTENSION.planning 0 & #最後面數字是一開始的bounding box expand
done
