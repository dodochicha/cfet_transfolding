# import modules
import numpy as np 
import matplotlib.pyplot as plt 
import matplotlib.patches as patches
from matplotlib.lines import Line2D as line
from matplotlib.pyplot import figure
import sys
  
#draw track

def gridLine(horizontal, length, pos):
    if horizontal:
        return line([i for i in range(length)], [pos for i in range(length)], linestyle='--', color='black')
    else:
        return line([pos for i in range(length)], [i for i in range(length)], linestyle='--', color='black')

class layout:
    def __init__(self, title, trackNum, cellWidth, gridSpace=2):
        fig = plt.figure(figsize=(20,20))
        self.ax = fig.add_subplot(1,1,1)
        self.trackNum = trackNum
        self.cellWidth = cellWidth
        self.gridSpace = gridSpace

        for track in range(trackNum):
            self.addGridLineH(track)
        for col in range(cellWidth):
            self.addGridLineV(col)

        self.ax.set_xlim([-2*gridSpace,self.gridSpace*cellWidth+1])
        self.ax.set_ylim([-2*gridSpace,self.gridSpace*trackNum+1])

        plt.yticks([self.gridSpace*i for i in range(trackNum)], ["track{}".format(trackNum-i-1) for i in range(trackNum)])
        plt.xticks([self.gridSpace*i for i in range(cellWidth)], ["col{}".format(i) for i in range(cellWidth)])

        self.m0Height = gridSpace * 0.4
        self.m1Width = gridSpace * 0.3
        self.m2Height = gridSpace * 0.2
        self.CASize = gridSpace * 0.2
        self.V01Size = gridSpace * 0.3
        self.m1Width = gridSpace * 0.4
        self.ax.set_title(title)

    def addGridLineH(self, track):
        self.ax.add_line(gridLine(True, self.gridSpace*self.cellWidth, self.trackPos(track)))
    def addGridLineV(self, col):
        self.ax.add_line(gridLine(False, self.gridSpace*self.trackNum, self.colPos(col)))

    def trackPos(self, track):
        return self.gridSpace * (self.trackNum-track-1)
    def colPos(self, col):
        return self.gridSpace * col
        
    def addM0(self, track, col, length):
        self.ax.add_patch(
            patches.Rectangle(
                (self.colPos(col) - 1/2*self.gridSpace,self.trackPos(track)-1/2*self.m0Height),
                length*self.gridSpace,
                self.m0Height,
                alpha=0.2,
                facecolor='gray',
                edgecolor='black',
                linewidth=2))

    def addM2(self, track, col, length):
        self.ax.add_patch(
            patches.Rectangle(
                (self.colPos(col) - 1/2*self.gridSpace,self.trackPos(track)-1/2*self.m2Height),
                length*self.gridSpace,
                self.m2Height,
                alpha=0.2,
                facecolor='green',
                edgecolor='black',
                linewidth=2))

    def addCA(self, track, col, netName):
        CAx = self.colPos(col) - 1/2*self.CASize
        CAy = self.trackPos(track)-1/2*self.CASize
        self.ax.add_patch(
            patches.Rectangle(
                (CAx, CAy),
                self.CASize,
                self.CASize,
                alpha=0.2,
                facecolor='red',
                edgecolor='red',
                label=netName,
                linewidth=2))
        self.ax.text(CAx, CAy, netName, fontsize=10)

    def addV01(self, track, col, netName):
        x = self.colPos(col) - 1/2*self.V01Size
        y = self.trackPos(track)-1/2*self.V01Size
        self.ax.add_patch(
            patches.Rectangle(
                (x, y),
                self.V01Size,
                self.V01Size,
                alpha=0.3,
                facecolor='blue',
                edgecolor='blue',
                label=netName,
                linewidth=2))
        self.ax.text(x, y, netName, fontsize=20, color='red')


    def addM1(self, col, track, length):
        self.ax.add_patch(
            patches.Rectangle(
                (self.colPos(col)-1/2*self.m1Width ,self.trackPos(track+length-1)-1/2*self.gridSpace),
                self.m1Width,
                length*self.gridSpace,
                alpha=0.2,
                facecolor='blue',
                edgecolor='black',
                linewidth=2))

    def addV12(self, track, col, netName):
        x = self.colPos(col) - 1/2*self.V01Size
        y = self.trackPos(track)-1/2*self.V01Size
        self.ax.add_patch(
            patches.Rectangle(
                (x, y),
                self.V01Size,
                self.V01Size,
                alpha=0.5,
                facecolor='green',
                edgecolor='green',
                label=netName,
                linewidth=2))
        self.ax.text(x, y, netName, fontsize=20, color='red')

    def addEOL(self, track, col):
        x = self.colPos(col)
        y = self.trackPos(track)
        self.ax.text(x, y, "EOL", fontsize=20, color='red')

    def addPA(self, net, track, col):
        x = self.colPos(col)
        y = self.trackPos(track)

        self.ax.text(x, y, net, fontsize=20, color='purple')

        print(net)

        self.ax.add_patch(
            patches.Rectangle(
                (x, y),
                self.V01Size,
                self.V01Size,
                alpha=0.5,
                facecolor='red',
                edgecolor='red',
                label=net,
                linewidth=2))



    def show(self):
        plt.show()
    def save(self,file):
        plt.savefig(file, bbox_inches='tight')
        plt.close()

    def addPmos(self, signalList):
        for i,net in enumerate(signalList):
            self.ax.text(self.colPos(i) , self.trackPos(0) + self.gridSpace , net, fontsize=8)

    def addNmos(self, signalList):
        for i,net in enumerate(signalList):
            self.ax.text(self.colPos(i), - self.gridSpace , net, fontsize=8)


def showLayout(fileName, showPin, savePath=None):
    with open(fileName, 'r') as file:
        lines = file.readlines()
        if(lines[0]=="unsat\n"):
            exit(1)
        cellInfo = lines[0].replace('\n','').split(' ')
        trackNum, cellWidth = int(cellInfo[0]), int(cellInfo[1])
        mylayout = layout(fileName, trackNum, cellWidth)

        i = 0
        #CA
        while "<CA>" not in lines[i]:
            i+=1
        i+=1
        #CA
        while "<m0>" not in lines[i]:
            ca = lines[i].replace('\n','').split(' ')
            net, track, col  = ca[0], int(ca[1]), int(ca[2])
            mylayout.addCA(track, col, net)
            i+=1
        i+=1

        #m0
        while "<v01>" not in lines[i]:
            segment = lines[i].replace('\n','').split(' ')
            net, track, col, length = segment[0], int(segment[1]), int(segment[2]), int(segment[3])
            mylayout.addM0(track, col, length)
            i+=1
        i+=1

        # v01
        while "<m1>" not in lines[i]:
            via = lines[i].replace('\n','').split(' ')
            net, track, col  = via[0], int(via[1]), int(via[2])
            mylayout.addV01(track, col, net)
            i+=1
        i+=1

        # m1
        while "<v12>" not in lines[i]:
            segment = lines[i].replace('\n','').split(' ')
            net, col, track, length = segment[0], int(segment[1]), int(segment[2]), int(segment[3])
            mylayout.addM1(col, track, length)
            i+=1
        i+=1

        # v12
        while "<m2>" not in lines[i]:
            via = lines[i].replace('\n','').split(' ')
            net, track, col  = via[0], int(via[1]), int(via[2])
            mylayout.addV12(track, col, net)
            i+=1
        i+=1

        #m2
        while "<Placement>" not in lines[i]:
            segment = lines[i].replace('\n','').split(' ')
            net, track, col, length = segment[0], int(segment[1]), int(segment[2]), int(segment[3])
            mylayout.addM2(track, col, length)
            i+=1
        i+=1

        pmos = lines[i].replace('\n','').split(' ')[0:-1]
        nmos = lines[i+1].replace('\n','').split(' ')[0:-1]
        mylayout.addPmos(pmos)
        mylayout.addNmos(nmos)

        if(savePath != None):
            mylayout.save(savePath)
        else:
            mylayout.show()

        
if __name__ == "__main__":
    fileName = sys.argv[1]
    showPin = True
    for i in range(2,len(sys.argv)):
        if sys.argv[i] == "-pin":
            showPin = False
    if len(sys.argv) == 2:
        showLayout(fileName, showPin)
    else:
        showLayout(fileName, showPin, sys.argv[2])
