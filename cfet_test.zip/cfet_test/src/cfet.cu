#include "cfet.cuh"

#include <chrono>
#include <iostream>
#include <map>
#include <queue>
#include <sstream>
#include <unordered_map>
#include <vector>

CFET::CFET(const std::map<std::string, float>& attributes) {
    max_cfet_width = attributes.at("max_cfet_width");
    diffusion_break_constraint = attributes.at("diffusion_break_constraint");
    max_placement_size = attributes.at("max_placement_size");
    max_allowable_cell_height = attributes.at("max_allowable_cell_height");
    relaxation_parameter = attributes.at("relaxation_parameter");
    num_nodes_parsed_to_gpu = attributes.at("num_nodes_parsed_to_gpu");
}

Shape::Shape() {
    num_row = 0;
    num_finger = 0;
    id = 0;
}
Transistor::Transistor() {}

Signal::Signal() {}

Pshape::Pshape() {}

Node::Node() { fill = 0; }

Lambda::Lambda() {}
