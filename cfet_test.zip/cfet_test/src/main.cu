#include <cuda_runtime.h>

#include <iostream>
#include <cassert>
#include <chrono>
#include <fstream>
#include <map>
#include <queue>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <omp.h>

#include "cfet.h"
#include "cfet_cuda.cuh"

__global__ void kernel(MyClass* d_data) {
    int idx = threadIdx.x + blockIdx.x * blockDim.x;
    d_data[idx].a += 1;
    d_data[idx].b *= 2.0f;
}

int main(int argc, char **argv) {
    std::cout << "Hello, World!" << std::endl;

    assert(argc == 3);

    // Open the input file for reading
    std::ifstream fin(argv[1]);
    // Check if the input file was opened successfully
    if (!fin) {
        std::cerr << "Error: Could not open input file " << argv[1] << "\n";
        return 1;
    }

    // Open the output file for writing
    std::ofstream fout(argv[2]);
    // Check if the output file was opened successfully
    if (!fout) {
        std::cerr << "Error: Could not open output file " << argv[2] << "\n";
        return 1;
    }
    auto start = std::chrono::high_resolution_clock::now();
    int num_cores = omp_get_num_procs();
    std::cout << "Available CPU cores: " << num_cores << std::endl;
    omp_set_num_threads(16);
    parse_input(fin);
    new_tr_pairing();
    folding_shape_generation();
    placement();

    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    std::cout << "Time taken : " << elapsed.count() << " seconds" << std::endl;
    return 0;


    // const int N = 10;
    // MyClass h_data[N]; // Host data

    // // Initialize data
    // for (int i = 0; i < N; i++) {
    //     h_data[i] = MyClass(i, 1.0f * i);
    // }

    // MyClass *d_data;
    // cudaMalloc(&d_data, sizeof(MyClass) * N); // Allocate device memory

    // cudaMemcpy(d_data, h_data, sizeof(MyClass) * N, cudaMemcpyHostToDevice); // Copy data to device

    // // Launch kernel
    // kernel<<<1, N>>>(d_data);

    // cudaMemcpy(h_data, d_data, sizeof(MyClass) * N, cudaMemcpyDeviceToHost); // Copy data back to host

    // // Check results
    // for (int i = 0; i < N; i++) {
    //     std::cout << "a: " << h_data[i].a << ", b: " << h_data[i].b << std::endl;
    // }

    // cudaFree(d_data); // Free device memory
    // return 0;
}

