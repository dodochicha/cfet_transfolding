#include <cuda_runtime.h>
#include <omp.h>

#include <cassert>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <mutex>
#include <queue>
#include <sstream>
#include <unordered_map>
#include <vector>

#include "cfet.h"

// void CFET::placement_multi_row_search_tree_bottom_up_bfs() {
//     for (Transistor *p : pmos) {
//         Transistor *n = tr_pairs[p];
//         p->num_finger = (p->width - 0.1) / max_cfet_width + 1;
//         n->num_finger = (n->width - 0.1) / max_cfet_width + 1;
//     }

//     // std::vector<Pshape *> placement_cand;
//     int tr_size_sum = 0;
//     int min_cell_area = std::numeric_limits<int>::max() - 1;
//     int min_macro_area = std::numeric_limits<int>::max() - 1;

//     for (Transistor *tr : pmos) {
//         tr_size_sum = tr_size_sum + std::max(tr->num_finger, tr_pairs[tr]->num_finger);
//     }

//     int target_area = tr_size_sum;

//     // assign shape to each transistor
//     for (Transistor *tr : pmos) {
//         std::vector<Lambda *> multi_row_config;
//         for (auto _p_shape : phi_merged[tr]) {
//             for (auto lamb : _p_shape.second) {
//                 multi_row_config.push_back(lamb);
//             }
//         }
//         multi_row_configs.insert(std::make_pair(tr, multi_row_config));
//     }

//     while (final_placement_cand.size() == 0) {
//         std::cout << "target_area: " << target_area << std::endl;
//         std::queue<Node *> q;
//         Node *root = new Node();
//         std::vector<Transistor *> remained_pmos(pmos);
//         root->name = "root";
//         root->remained_pmos = remained_pmos;
//         root->tr_left_sum = tr_size_sum;
//         q.push(root);
//         while (q.empty() == false) {
//             // std::cout << "q.size(): " << q.size() << std::endl;
//             // if (q.size() > 100000) {
//             //     std::cout << "q.size(): " << q.size() << std::endl;
//             // }
//             if (final_placement_cand.size() >= max_placement_size) {
//                 break;
//             }
//             Node *current_node = q.front();
//             // branch
//             // std::cout << "current_node->remained_pmos.size(): " << current_node->remained_pmos.size() << std::endl;
//             if (current_node->remained_pmos.size() != 0) {
//                 for (Transistor *br_tr : current_node->remained_pmos) {
//                     Node *br_node = new Node();
//                     std::vector<Transistor *> remained_pmos(current_node->remained_pmos);
//                     for (auto it = remained_pmos.begin(); it != remained_pmos.end();) {
//                         if (*it == br_tr) {
//                             it = remained_pmos.erase(it);  // 刪除元素並返回新的位置
//                         } else {
//                             ++it;
//                         }
//                     }
//                     br_node->remained_pmos = remained_pmos;
//                     br_node->tr = br_tr;
//                     br_node->tr_left_sum = current_node->tr_left_sum - std::max(br_tr->num_finger, tr_pairs[br_tr]->num_finger);
//                     // create partial shape
//                     if (current_node->name == "root") {
//                         std::vector<Pshape *> partial_placement;
//                         for (auto lamb : multi_row_configs[br_tr]) {
//                             Pshape *pshape = new Pshape();
//                             // multi-row
//                             pshape->multirow_area = std::max(br_tr->num_finger, tr_pairs[br_tr]->num_finger);
//                             pshape->multirow_tr_shape_up = lamb->config_up;
//                             pshape->multirow_tr_shape_down = lamb->config_down;
//                             pshape->multirow_tr_permutation_up.assign(lamb->config_up.size(), std::vector<Transistor *>(lamb->config_up[0].size()));
//                             pshape->multirow_tr_permutation_down.assign(lamb->config_down.size(), std::vector<Transistor *>(lamb->config_down[0].size()));
//                             pshape->height = 0;
//                             pshape->width = 0;
//                             pshape->top_width = 0;
//                             for (int row = 0; row < lamb->config_up.size(); row++) {
//                                 pshape->most_right_idx.push_back(0);
//                                 for (int col = 0; col < lamb->config_up[row].size(); col++) {
//                                     if (lamb->config_up[row][col] != 2) {
//                                         pshape->multirow_tr_permutation_up[row][col] = tr_pairs[br_tr];
//                                         pshape->most_right_idx[row] = col;
//                                         pshape->height = row + 1;
//                                     } else {
//                                         pshape->multirow_tr_permutation_up[row][col] = nullptr;
//                                     }
//                                     if (lamb->config_down[row][col] != 2) {
//                                         pshape->multirow_tr_permutation_down[row][col] = br_tr;
//                                         pshape->most_right_idx[row] = col;
//                                         pshape->height = row + 1;
//                                     } else {
//                                         pshape->multirow_tr_permutation_down[row][col] = nullptr;
//                                     }
//                                     if (lamb->config_up[row][col] != 2 || lamb->config_down[row][col] != 2) {
//                                         if (col + 1 > pshape->width) {
//                                             pshape->width = col + 1;
//                                         }
//                                     }
//                                 }
//                                 if (row == lamb->config_up.size() - 1) {
//                                     for (int col = 0; col < lamb->config_up[row].size(); col++) {
//                                         if (lamb->config_up[row][col] != 2 || lamb->config_down[row][col] != 2) {
//                                             pshape->top_width = col + 1;
//                                         }
//                                     }
//                                 }
//                             }
//                             pshape->multirow_macro_area = (pshape->width) * pshape->height;
//                             // for (int i = 0; i < pshape->multirow_tr_permutation_up.size(); i++) {
//                             //     for (int j = 0; j < pshape->multirow_tr_permutation_up[i].size(); j++) {
//                             //         if (pshape->multirow_tr_permutation_up[i][j] == nullptr) std::cout << "  x ";
//                             //         else std::cout << pshape->multirow_tr_permutation_up[i][j]->name << " ";
//                             //     }
//                             //     std::cout << std::endl;
//                             // }
//                             // std::cout << "--" << std::endl;
//                             // for (int i = 0; i < pshape->multirow_tr_permutation_down.size(); i++) {
//                             //     for (int j = 0; j < pshape->multirow_tr_permutation_down[i].size(); j++) {
//                             //         if (pshape->multirow_tr_permutation_down[i][j] == nullptr) std::cout << "  x ";
//                             //         else std::cout << pshape->multirow_tr_permutation_down[i][j]->name << " ";
//                             //     }
//                             //     std::cout << std::endl;
//                             // }
//                             // std::cout << std::endl;
//                             partial_placement.push_back(pshape);
//                         }
//                         // assign partial_placement
//                         br_node->partial_shapes = partial_placement;
//                     } else {
//                         int min_potential_macro_area = std::numeric_limits<int>::max();
//                         std::vector<Pshape *> new_partial_placement;
//                         for (auto old_pshape : current_node->partial_shapes) {
//                             for (auto lamb : multi_row_configs[br_tr]) {
//                                 auto new_tr_permutation = old_pshape->tr_permutaton;
//                                 auto new_tr_shape_id = old_pshape->tr_shape_id;
//                                 auto new_ds_array = old_pshape->ds_array;
//                                 for (int row = std::max(0, static_cast<int>(old_pshape->height - lamb->config_up.size())); row <= old_pshape->height; row++)
//                                 {
//                                     int col;
//                                     if (row < old_pshape->multirow_tr_shape_up.size()) {
//                                         col = old_pshape->most_right_idx[row];
//                                     } else {
//                                         col = 0;
//                                     }
//                                     while (true) {
//                                         if (merge_enable(old_pshape, lamb, tr_pairs[br_tr], br_tr, row, col)) {
//                                             Pshape *pshape = merge(old_pshape, lamb, tr_pairs[br_tr], br_tr, row, col);
//                                             if (pshape->height > max_allowable_cell_height) {
//                                                 delete pshape;
//                                                 pshape = nullptr;
//                                                 break;
//                                             }
//                                             int low_bound = std::numeric_limits<int>::max();
//                                             for (int h = pshape->height; h <= max_allowable_cell_height; h++) {
//                                                 int _low_bound =
//                                                     std::max(pshape->width, (pshape->top_width + br_node->tr_left_sum + (h - pshape->height + 1) - 1) /
//                                                                                 (h - pshape->height + 1));
//                                                 _low_bound = _low_bound * h;
//                                                 if (_low_bound < low_bound) {
//                                                     low_bound = _low_bound;
//                                                 }
//                                             }
//                                             // for (int i = 0; i < pshape->multirow_tr_permutation_up.size(); i++) {
//                                             //     for (int j = 0; j < pshape->multirow_tr_permutation_up[i].size(); j++) {
//                                             //         if (pshape->multirow_tr_permutation_up[i][j] == nullptr) std::cout << "  x ";
//                                             //         else std::cout << pshape->multirow_tr_permutation_up[i][j]->name << " ";
//                                             //     }
//                                             //     std::cout << std::endl;
//                                             // }
//                                             // std::cout << "--" << std::endl;
//                                             // for (int i = 0; i < pshape->multirow_tr_permutation_down.size(); i++) {
//                                             //     for (int j = 0; j < pshape->multirow_tr_permutation_down[i].size(); j++) {
//                                             //         if (pshape->multirow_tr_permutation_down[i][j] == nullptr) std::cout << "  x ";
//                                             //         else std::cout << pshape->multirow_tr_permutation_down[i][j]->name << " ";
//                                             //     }
//                                             //     std::cout << std::endl;
//                                             // }
//                                             // std::cout << "current_node->tr_left_sum: " << current_node->tr_left_sum << std::endl;
//                                             // std::cout << "low_bound: " << low_bound << std::endl;
//                                             // std::cout << std::endl;
//                                             if (low_bound > target_area) {
//                                                 delete pshape;
//                                                 pshape = nullptr;
//                                                 break;
//                                             }
//                                             if (low_bound < min_potential_macro_area) {
//                                                 for (auto item : new_partial_placement) {
//                                                     delete item;
//                                                     item = nullptr;
//                                                 }
//                                                 new_partial_placement.clear();
//                                                 new_partial_placement.shrink_to_fit();
//                                                 min_potential_macro_area = low_bound;
//                                                 new_partial_placement.push_back(pshape);
//                                             } else if (low_bound == min_potential_macro_area) {
//                                                 new_partial_placement.push_back(pshape);
//                                             } else {
//                                                 delete pshape;
//                                                 pshape = nullptr;
//                                             }
//                                             break;
//                                         }
//                                         col++;
//                                     }
//                                 }
//                             }
//                         }
//                         br_node->partial_shapes = new_partial_placement;
//                     }
//                     if (br_node->partial_shapes.size() != 0) {
//                         q.push(br_node);
//                     } else {
//                         delete br_node;
//                         br_node = nullptr;
//                     }
//                 }

//                 for (auto pshape : current_node->partial_shapes) {
//                     delete pshape;
//                     pshape = nullptr;
//                 }
//                 delete current_node;
//                 current_node = nullptr;
//             } else {  // leaf
//                 for (auto pshape : current_node->partial_shapes) {
//                     if (final_placement_cand.size() < max_placement_size) {
//                         if (pshape->multirow_macro_area <= target_area) {
//                             // std::cout << "pshape->multirow_macro_area: " << pshape->multirow_macro_area << std::endl;
//                             // for (int i = 0; i < pshape->multirow_tr_permutation_up.size(); i++) {
//                             //     for (int j = 0; j < pshape->multirow_tr_permutation_up[i].size(); j++) {
//                             //         std::cout << pshape->multirow_tr_permutation_up[i][j]->name << " ";
//                             //     }
//                             //     std::cout << std::endl;
//                             // }
//                             // std::cout << "--" << std::endl;
//                             // for (int i = 0; i < pshape->multirow_tr_permutation_down.size(); i++) {
//                             //     for (int j = 0; j < pshape->multirow_tr_permutation_down[i].size(); j++) {
//                             //         std::cout << pshape->multirow_tr_permutation_down[i][j]->name << " ";
//                             //     }
//                             //     std::cout << std::endl;
//                             // }
//                             final_placement_cand.push_back(pshape);
//                         } else {
//                             delete pshape;
//                             pshape = nullptr;
//                         }
//                     } else {
//                         break;
//                     }
//                 }
//                 delete current_node;
//                 current_node = nullptr;
//             }
//             // std::cout << "final_placement_cand.size(): " << final_placement_cand.size() << std::endl;
//             if (final_placement_cand.size() >= max_placement_size) {
//                 break;
//             }
//             q.pop();
//         }

//         target_area++;
//     }

//     std::cout << "number of cell: " << final_placement_cand.size() << std::endl;
//     // std::cout << "min_macro_area: " << min_macro_area << std::endl;
//     int place_cand_id = 0;
//     for (auto pshape : final_placement_cand) {
//         std::cout << "min_macro_area: " << pshape->multirow_macro_area << std::endl;
//         std::cout << "#" << place_cand_id << std::endl;
//         // print transistor name
//         for (int i = 0; i < pshape->height; i++) {
//             for (int j = 0; j < pshape->width; j++) {
//                 if (pshape->multirow_tr_permutation_up[i][j] == nullptr) {
//                     std::cout << "     ";
//                 } else {
//                     std::cout << std::left << std::setw(4) << pshape->multirow_tr_permutation_up[i][j]->name << " ";
//                 }
//             }
//             std::cout << std::endl;
//         }
//         std::cout << "--" << std::endl;
//         for (int i = 0; i < pshape->height; i++) {
//             for (int j = 0; j < pshape->width; j++) {
//                 if (pshape->multirow_tr_permutation_down[i][j] == nullptr) {
//                     std::cout << "     ";
//                 } else {
//                     std::cout << std::left << std::setw(4) << pshape->multirow_tr_permutation_down[i][j]->name << " ";
//                 }
//             }
//             std::cout << std::endl;
//         }
//         // print active
//         for (int i = 0; i < pshape->height; i++) {
//             for (int j = 0; j < pshape->width; j++) {
//                 Transistor *tr_n = pshape->multirow_tr_permutation_up[i][j];
//                 switch (pshape->multirow_tr_shape_up[i][j]) {
//                     case 0:
//                         std::cout << std::left << std::setw(7) << tr_n->drain->name << " " << std::left << std::setw(7) << tr_n->gate->name << " " <<
//                         std::left
//                                   << std::setw(7) << tr_n->source->name << " ";
//                         break;
//                     case 1:
//                         std::cout << std::left << std::setw(7) << tr_n->source->name << " " << std::left << std::setw(7) << tr_n->gate->name << " " <<
//                         std::left
//                                   << std::setw(7) << tr_n->drain->name << " ";
//                         break;
//                     case 2:
//                         std::cout << "------------------------";
//                         break;
//                 }
//             }
//             std::cout << std::endl;
//         }
//         std::cout << "--" << std::endl;
//         for (int i = 0; i < pshape->height; i++) {
//             for (int j = 0; j < pshape->width; j++) {
//                 Transistor *tr_p = pshape->multirow_tr_permutation_down[i][j];
//                 switch (pshape->multirow_tr_shape_down[i][j]) {
//                     case 0:
//                         std::cout << std::left << std::setw(7) << tr_p->drain->name << " " << std::left << std::setw(7) << tr_p->gate->name << " " <<
//                         std::left
//                                   << std::setw(7) << tr_p->source->name << " ";
//                         break;
//                     case 1:
//                         std::cout << std::left << std::setw(7) << tr_p->source->name << " " << std::left << std::setw(7) << tr_p->gate->name << " " <<
//                         std::left
//                                   << std::setw(7) << tr_p->drain->name << " ";
//                         break;
//                     case 2:
//                         std::cout << "------------------------";
//                         break;
//                 }
//             }
//             std::cout << std::endl;
//         }
//         for (int i = 0; i < pshape->height; i++) {
//             for (int j = 0; j < pshape->width; j++) {
//                 std::cout << pshape->multirow_tr_shape_up[i][j];
//             }
//             std::cout << std::endl;
//         }
//         std::cout << "--" << std::endl;
//         for (int i = 0; i < pshape->height; i++) {
//             for (int j = 0; j < pshape->width; j++) {
//                 std::cout << pshape->multirow_tr_shape_down[i][j];
//             }
//             std::cout << std::endl;
//         }
//         std::cout << std::endl;
//         place_cand_id++;
//     }
// }

std::pair<std::vector<Node *>, std::vector<Pshape *>> bfs_placement(int target_area) {
    auto start_bfs = std::chrono::high_resolution_clock::now();
    std::vector<Pshape *> placement_cand;
    std::cout << "target_area: " << target_area << std::endl;
    std::queue<Node *> q;
    Node *root = new Node();
    std::vector<Transistor *> remained_pmos(pmos);
    root->name = "root";
    root->remained_pmos = remained_pmos;
    root->tr_left_sum = tr_size_sum;
    Transistor *root_tr = new Transistor();
    root_tr->name = "root_tr";
    root->tr = root_tr;
    q.push(root);
    while (q.empty() == false) {
        // std::cout << "q.size(): " << q.size() << std::endl;
        if (q.size() >= num_nodes_parsed_to_gpu) {
            std::vector<Node *> node_to_be_processed;
            while (q.empty() == false) {
                Node *n = q.front();
                node_to_be_processed.push_back(n);
                q.pop();
            }
            auto end_bfs = std::chrono::high_resolution_clock::now();
            std::chrono::duration<double> elapsed_bfs = end_bfs - start_bfs;
            std::cout << "BFS Time taken : " << elapsed_bfs.count() << " seconds" << std::endl;
            return std::make_pair(node_to_be_processed, std::vector<Pshape *>());
        }
        if (placement_cand.size() >= max_placement_size) {
            break;
        }
        Node *current_node = q.front();
        // branch
        // std::cout << "current_node->remained_pmos.size(): " << current_node->remained_pmos.size() << std::endl;
        if (current_node->remained_pmos.size() != 0) {
            // #pragma omp parallel for schedule(dynamic)
            for (Transistor *br_tr : current_node->remained_pmos) {
                Node *br_node = new Node();
                std::vector<Transistor *> remained_pmos(current_node->remained_pmos);
                for (auto it = remained_pmos.begin(); it != remained_pmos.end();) {
                    if (*it == br_tr) {
                        it = remained_pmos.erase(it);  // 刪除元素並返回新的位置
                    } else {
                        ++it;
                    }
                }
                br_node->parent = current_node;
                br_node->remained_pmos = remained_pmos;
                br_node->tr = br_tr;
                br_node->tr_left_sum = current_node->tr_left_sum - std::max(br_tr->num_finger, tr_pairs[br_tr]->num_finger);
                // create partial shape
                if (current_node->name == "root") {
                    std::vector<Pshape *> partial_placement;
                    for (auto lamb : multi_row_configs[br_tr]) {
                        Pshape *pshape = new Pshape();
                        // multi-row
                        pshape->multirow_area = std::max(br_tr->num_finger, tr_pairs[br_tr]->num_finger);
                        pshape->multirow_tr_shape_up = lamb->config_up;
                        pshape->multirow_tr_shape_down = lamb->config_down;
                        pshape->multirow_tr_permutation_up.assign(lamb->config_up.size(), std::vector<Transistor *>(lamb->config_up[0].size()));
                        pshape->multirow_tr_permutation_down.assign(lamb->config_down.size(), std::vector<Transistor *>(lamb->config_down[0].size()));
                        pshape->height = 0;
                        pshape->width = 0;
                        pshape->top_width = 0;
                        for (int row = 0; row < lamb->config_up.size(); row++) {
                            pshape->most_right_idx.push_back(0);
                            for (int col = 0; col < lamb->config_up[row].size(); col++) {
                                if (lamb->config_up[row][col] != 2) {
                                    pshape->multirow_tr_permutation_up[row][col] = tr_pairs[br_tr];
                                    pshape->most_right_idx[row] = col;
                                    pshape->height = row + 1;
                                } else {
                                    pshape->multirow_tr_permutation_up[row][col] = nullptr;
                                }
                                if (lamb->config_down[row][col] != 2) {
                                    pshape->multirow_tr_permutation_down[row][col] = br_tr;
                                    pshape->most_right_idx[row] = col;
                                    pshape->height = row + 1;
                                } else {
                                    pshape->multirow_tr_permutation_down[row][col] = nullptr;
                                }
                                if (lamb->config_up[row][col] != 2 || lamb->config_down[row][col] != 2) {
                                    if (col + 1 > pshape->width) {
                                        pshape->width = col + 1;
                                    }
                                }
                            }
                            if (row == lamb->config_up.size() - 1) {
                                for (int col = 0; col < lamb->config_up[row].size(); col++) {
                                    if (lamb->config_up[row][col] != 2 || lamb->config_down[row][col] != 2) {
                                        pshape->top_width = col + 1;
                                    }
                                }
                            }
                        }
                        pshape->multirow_macro_area = (pshape->width) * pshape->height;
                        // for (int i = 0; i < pshape->multirow_tr_permutation_up.size(); i++) {
                        //     for (int j = 0; j < pshape->multirow_tr_permutation_up[i].size(); j++) {
                        //         if (pshape->multirow_tr_permutation_up[i][j] == nullptr) std::cout << "  x ";
                        //         else std::cout << pshape->multirow_tr_permutation_up[i][j]->name << " ";
                        //     }
                        //     std::cout << std::endl;
                        // }
                        // std::cout << "--" << std::endl;
                        // for (int i = 0; i < pshape->multirow_tr_permutation_down.size(); i++) {
                        //     for (int j = 0; j < pshape->multirow_tr_permutation_down[i].size(); j++) {
                        //         if (pshape->multirow_tr_permutation_down[i][j] == nullptr) std::cout << "  x ";
                        //         else std::cout << pshape->multirow_tr_permutation_down[i][j]->name << " ";
                        //     }
                        //     std::cout << std::endl;
                        // }
                        // std::cout << std::endl;
                        partial_placement.push_back(pshape);
                    }
                    // assign partial_placement
                    br_node->partial_shapes = partial_placement;
                } else {
                    int min_potential_macro_area = std::numeric_limits<int>::max();
                    std::vector<Pshape *> new_partial_placement;
                    for (auto old_pshape : current_node->partial_shapes) {
                        for (auto lamb : multi_row_configs[br_tr]) {
                            auto new_tr_permutation = old_pshape->tr_permutaton;
                            auto new_tr_shape_id = old_pshape->tr_shape_id;
                            auto new_ds_array = old_pshape->ds_array;
                            for (int row = std::max(0, static_cast<int>(old_pshape->height - lamb->config_up.size())); row <= old_pshape->height; row++) {
                                int col;
                                if (row < old_pshape->multirow_tr_shape_up.size()) {
                                    col = old_pshape->most_right_idx[row];
                                } else {
                                    col = 0;
                                }
                                while (true) {
                                    if (merge_enable(old_pshape, lamb, tr_pairs[br_tr], br_tr, row, col)) {
                                        Pshape *pshape = merge(old_pshape, lamb, tr_pairs[br_tr], br_tr, row, col);
                                        if (pshape->height > max_allowable_cell_height) {
                                            delete pshape;
                                            pshape = nullptr;
                                            break;
                                        }
                                        int low_bound = std::numeric_limits<int>::max();
                                        for (int h = pshape->height; h <= max_allowable_cell_height; h++) {
                                            int _low_bound = std::max(pshape->width, (pshape->top_width + br_node->tr_left_sum + (h - pshape->height + 1) - 1) /
                                                                                         (h - pshape->height + 1));
                                            _low_bound = _low_bound * h;
                                            if (_low_bound < low_bound) {
                                                low_bound = _low_bound;
                                            }
                                        }
                                        // for (int i = 0; i < pshape->multirow_tr_permutation_up.size(); i++) {
                                        //     for (int j = 0; j < pshape->multirow_tr_permutation_up[i].size(); j++) {
                                        //         if (pshape->multirow_tr_permutation_up[i][j] == nullptr) std::cout << "  x ";
                                        //         else std::cout << pshape->multirow_tr_permutation_up[i][j]->name << " ";
                                        //     }
                                        //     std::cout << std::endl;
                                        // }
                                        // std::cout << "--" << std::endl;
                                        // for (int i = 0; i < pshape->multirow_tr_permutation_down.size(); i++) {
                                        //     for (int j = 0; j < pshape->multirow_tr_permutation_down[i].size(); j++) {
                                        //         if (pshape->multirow_tr_permutation_down[i][j] == nullptr) std::cout << "  x ";
                                        //         else std::cout << pshape->multirow_tr_permutation_down[i][j]->name << " ";
                                        //     }
                                        //     std::cout << std::endl;
                                        // }
                                        // std::cout << "current_node->tr_left_sum: " << current_node->tr_left_sum << std::endl;
                                        // std::cout << "low_bound: " << low_bound << std::endl;
                                        // std::cout << std::endl;
                                        if (low_bound > target_area) {
                                            delete pshape;
                                            pshape = nullptr;
                                            break;
                                        }
                                        if (low_bound < min_potential_macro_area) {
                                            for (auto item : new_partial_placement) {
                                                delete item;
                                                item = nullptr;
                                            }
                                            new_partial_placement.clear();
                                            new_partial_placement.shrink_to_fit();
                                            min_potential_macro_area = low_bound;
                                            new_partial_placement.push_back(pshape);
                                        } else if (low_bound == min_potential_macro_area) {
                                            new_partial_placement.push_back(pshape);
                                        } else {
                                            delete pshape;
                                            pshape = nullptr;
                                        }
                                        break;
                                    }
                                    col++;
                                }
                            }
                        }
                    }
                    br_node->partial_shapes = new_partial_placement;
                }
                if (br_node->partial_shapes.size() != 0) {
                    q.push(br_node);
                } else {
                    delete br_node;
                    br_node = nullptr;
                }
            }

            for (auto pshape : current_node->partial_shapes) {
                delete pshape;
                pshape = nullptr;
            }
            // delete current_node;
            // current_node = nullptr;
        } else {  // leaf
            for (auto pshape : current_node->partial_shapes) {
                if (placement_cand.size() < max_placement_size) {
                    if (pshape->multirow_macro_area <= target_area) {
                        // std::cout << "pshape->multirow_macro_area: " << pshape->multirow_macro_area << std::endl;
                        // for (int i = 0; i < pshape->multirow_tr_permutation_up.size(); i++) {
                        //     for (int j = 0; j < pshape->multirow_tr_permutation_up[i].size(); j++) {
                        //         std::cout << pshape->multirow_tr_permutation_up[i][j]->name << " ";
                        //     }
                        //     std::cout << std::endl;
                        // }
                        // std::cout << "--" << std::endl;
                        // for (int i = 0; i < pshape->multirow_tr_permutation_down.size(); i++) {
                        //     for (int j = 0; j < pshape->multirow_tr_permutation_down[i].size(); j++) {
                        //         std::cout << pshape->multirow_tr_permutation_down[i][j]->name << " ";
                        //     }
                        //     std::cout << std::endl;
                        // }
                        placement_cand.push_back(pshape);
                    } else {
                        delete pshape;
                        pshape = nullptr;
                    }
                } else {
                    break;
                }
            }
            // delete current_node;
            // current_node = nullptr;
        }
        // std::cout << "placement_cand.size(): " << placement_cand.size() << std::endl;
        if (placement_cand.size() >= max_placement_size) {
            break;
        }
        q.pop();
    }
    auto end_bfs = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed_bfs = end_bfs - start_bfs;
    std::cout << "BFS Time taken : " << elapsed_bfs.count() << " seconds" << std::endl;
    return std::make_pair(std::vector<Node *>(), placement_cand);
}

std::pair<std::vector<Node *>, std::vector<Permutation *>> bfs_placement_singlerow(int target_area) {
    std::vector<Permutation *> placement_cand;
    std::cout << "target_area: " << target_area << std::endl;
    std::queue<Node *> q;
    Node *root = new Node();
    std::vector<Transistor *> remained_pmos(pmos);
    root->name = "root";
    root->remained_pmos = remained_pmos;
    root->tr_left_sum = tr_size_sum;
    Transistor *root_tr = new Transistor();
    root_tr->name = "root_tr";
    root->tr = root_tr;
    q.push(root);
    while (q.empty() == false) {
        // std::cout << "q.size(): " << q.size() << std::endl;
        if (q.size() >= num_nodes_parsed_to_gpu) {
            std::vector<Node *> node_to_be_processed;
            while (q.empty() == false) {
                Node *n = q.front();
                node_to_be_processed.push_back(n);
                q.pop();
            }
            // std::cout << "return bfs" << std::endl;
            
            return std::make_pair(node_to_be_processed, std::vector<Permutation *>());
        }
        if (placement_cand.size() >= max_placement_size) {
            break;
        }
        Node *current_node = q.front();
        // std::cout << "current_node: " << current_node->tr->name << std::endl;
        // branch
        // std::cout << "current_node->remained_pmos.size(): " << current_node->remained_pmos.size() << std::endl;
        if (current_node->remained_pmos.size() != 0) {
            for (Transistor *br_tr : current_node->remained_pmos) {
                // std::cout << "br_tr: " << br_tr->name << std::endl;
                Node *br_node = new Node();
                std::vector<Transistor *> remained_pmos(current_node->remained_pmos);
                for (auto it = remained_pmos.begin(); it != remained_pmos.end();) {
                    if (*it == br_tr) {
                        it = remained_pmos.erase(it);  // 刪除元素並返回新的位置
                    } else {
                        ++it;
                    }
                }
                br_node->parent = current_node;
                br_node->remained_pmos = remained_pmos;
                br_node->tr = br_tr;
                br_node->tr_left_sum = current_node->tr_left_sum - std::max(br_tr->num_finger, tr_pairs[br_tr]->num_finger);
                // create partial shape
                if (current_node->name == "root") {
                    for (auto lamb : multi_row_configs[br_tr]) {
                        Permutation *p = new Permutation();
                        p->lamb_permutation.push_back(lamb->id);
                        p->size = 1;
                        p->width = std::max(br_tr->num_finger, tr_pairs[br_tr]->num_finger);
                        br_node->lamb_permutation.push_back(p);
                    }
                } else {
                    for (auto old_p : current_node->lamb_permutation) {
                        int old_lamb_id = old_p->lamb_permutation[old_p->size - 1];
                        for (auto new_lamb : multi_row_configs[br_tr]) {
                            int new_lamb_id = new_lamb->id;
                            int low_bound;
                            if (ds_dict[old_lamb_id * lamb_id + new_lamb_id]) {
                                low_bound = current_node->tr_left_sum + old_p->width;
                                if (low_bound > target_area) {
                                    continue;
                                } else {
                                    std::vector<int> new_lamb_permutation(old_p->lamb_permutation);
                                    new_lamb_permutation.push_back(new_lamb_id);
                                    Permutation *p = new Permutation();
                                    p->lamb_permutation = new_lamb_permutation;
                                    p->size = old_p->size + 1;
                                    p->width = old_p->width + std::max(br_tr->num_finger, tr_pairs[br_tr]->num_finger);
                                    br_node->lamb_permutation.push_back(p);
                                }
                            } else {
                                low_bound = current_node->tr_left_sum + old_p->width + 1;
                                if (low_bound > target_area) {
                                    continue;
                                } else {
                                    std::vector<int> new_lamb_permutation(old_p->lamb_permutation);
                                    new_lamb_permutation.push_back(new_lamb_id);
                                    Permutation *p = new Permutation();
                                    p->lamb_permutation = new_lamb_permutation;
                                    p->size = old_p->size + 1;
                                    p->width = old_p->width + std::max(br_tr->num_finger, tr_pairs[br_tr]->num_finger) + 1;
                                    br_node->lamb_permutation.push_back(p);
                                }
                            }
                        }
                    }
                }
                if (br_node->lamb_permutation.size() != 0) {
                    q.push(br_node);
                } else {
                    delete br_node;
                    br_node = nullptr;
                }
            }
        } else {  // leaf
            for (auto p : current_node->lamb_permutation) {
                if (p->width <= target_area) {
                    std::cout << "p->width: " << p->width << std::endl;
                    for (auto _lamb_id : p->lamb_permutation) {
                        std::cout << _lamb_id << " ";
                    }
                    std::cout << std::endl;
                    for (auto _lamb_id : p->lamb_permutation) {
                        auto lamb = lambda_dict[_lamb_id];
                        for (int i = 0; i < lamb->config_up.size(); i++) {
                            for (int j = 0; j < lamb->config_up[i].size(); j++) {
                                std::cout << lamb->config_up[i][j] << " ";
                            }
                        }
                    }
                    std::cout << std::endl;
                    std::cout << "--" << std::endl;
                    for (auto _lamb_id : p->lamb_permutation) {
                        auto lamb = lambda_dict[_lamb_id];
                        for (int i = 0; i < lamb->config_down.size(); i++) {
                            for (int j = 0; j < lamb->config_down[i].size(); j++) {
                                std::cout << lamb->config_down[i][j] << " ";
                            }
                        }
                    }
                    std::cout << std::endl;
                    for (auto _lamb_id : p->lamb_permutation) {
                        auto lamb = lambda_dict[_lamb_id];
                        auto tr_p = lamb->tr;
                        auto tr_n = tr_pairs[lamb->tr];
                        for (int i = 0; i < lamb->config_up.size(); i++) {
                            for (int j = 0; j < lamb->config_up[i].size(); j++) {
                                if (lamb->config_up[i][j] == 0) {
                                    std::cout << tr_p->drain->name << " " << tr_p->gate->name << " " << tr_p->source->name << " ";

                                } else if (lamb->config_up[i][j] == 1) {
                                    std::cout << tr_p->source->name << " " << tr_p->gate->name << " " << tr_p->drain->name << " ";
                                }
                            }
                        }
                    }
                    std::cout << std::endl;
                    std::cout << "--" << std::endl;
                    for (auto _lamb_id : p->lamb_permutation) {
                        auto lamb = lambda_dict[_lamb_id];
                        auto tr_p = lamb->tr;
                        auto tr_n = tr_pairs[lamb->tr];
                        for (int i = 0; i < lamb->config_down.size(); i++) {
                            for (int j = 0; j < lamb->config_down[i].size(); j++) {
                                if (lamb->config_down[i][j] == 0) {
                                    std::cout << tr_n->drain->name << " " << tr_n->gate->name << " " << tr_n->source->name << " ";

                                } else if (lamb->config_down[i][j] == 1) {
                                    std::cout << tr_n->source->name << " " << tr_n->gate->name << " " << tr_n->drain->name << " ";
                                }
                            }
                        }
                    }
                    std::cout << std::endl;
                    placement_cand.push_back(p);
                } else {
                    delete p;
                    p = nullptr;
                }
            }
        }
        q.pop();
    }

    return std::make_pair(std::vector<Node *>(), placement_cand);
}

std::vector<Pshape *> dfs_placement(Node *root_node, int target_area) {
    // std::cout << "dfs" << std::endl;
    // auto start_dfs = std::chrono::high_resolution_clock::now();
    int min_macro_area = std::numeric_limits<int>::max() - 1;
    std::vector<Pshape *> placement_cand;
    bool pruned = false;
    Node *root = root_node->parent;
    std::vector<Transistor *> remained_pmos(root_node->remained_pmos);
    Transistor *current_tr = root_node->tr;
    Node *current_node = root_node;

    if (root_node->remained_pmos.size() == 0) {
        return root_node->partial_shapes;
    }

    while (true) {
        if (final_placement_cand.size() >= max_placement_size) {
            break;
        }
        if (pruned) {
            // std::cout << "pruned!" << std::endl;
            pruned = false;
            while (true) {
                Node *n = current_node->parent;
                for (auto pshape : current_node->partial_shapes) {
                    delete pshape;
                }
                delete current_node;
                current_node = n;
                current_tr = n->tr;
                if (((current_node->remained_pmos.size() == 0 || current_node->fill == current_node->remained_pmos.size() - 1) && (current_node != root)) ==
                    false) {
                    break;
                }
            }
            current_node->fill++;
            if (current_node == root) {
                break;
            }
        } else if (current_node->remained_pmos.size() == 0) {
            // std::cout << "leaf!" << std::endl;
            if (current_node->partial_shapes.size() != 0) {
                for (auto pshape : current_node->partial_shapes) {
                    if (pshape->multirow_macro_area < min_macro_area) {
                        min_macro_area = pshape->multirow_macro_area;
                        for (auto item : placement_cand) {
                            delete item;
                            item = nullptr;
                        }
                        placement_cand.clear();
                        placement_cand.shrink_to_fit();
                        placement_cand.push_back(pshape);
                    } else if (pshape->multirow_macro_area == min_macro_area) {
                        placement_cand.push_back(pshape);
                    } else {
                        delete pshape;
                        pshape = nullptr;
                    }
                    if (placement_cand.size() >= max_placement_size) {
                        break;
                    }
                }
                // std::cout << "placement_cand.size(): " << placement_cand.size() << std::endl;
            } else {
                delete current_node;
            }
            if (placement_cand.size() >= max_placement_size) {
                break;
            }
            while ((current_node->remained_pmos.size() == 0 || current_node->fill == current_node->remained_pmos.size() - 1) && (current_node != root)) {
                Node *n = current_node->parent;
                // tr_left_sum = tr_left_sum + std::max(current_tr->num_finger, tr_pairs[current_tr]->num_finger);
                current_node = n;
                current_tr = n->tr;
            }
            current_node->fill++;
            if (current_node == root) {
                break;
            }
        } else {
            int min_potential_macro_area = std::numeric_limits<int>::max();
            if (current_node->partial_shapes.size() == 0) {
                current_node->partial_shapes.clear();
                current_node->partial_shapes.shrink_to_fit();
                pruned = true;
                continue;
            }
            Node *n = new Node();
            std::vector<Transistor *> remained_pmos = current_node->remained_pmos;
            Transistor *old_tr = current_tr;
            current_tr = remained_pmos[current_node->fill];
            std::vector<Pshape *> new_partial_placement;
            int low_bound;
            int tr_left_sum = current_node->tr_left_sum - std::max(current_tr->num_finger, tr_pairs[current_tr]->num_finger);
            for (auto old_pshape : current_node->partial_shapes) {
                // std::cout << "old_pshape: " << std::endl;
                // for (int r = 0; r < old_pshape->multirow_tr_shape_up.size(); r++) {
                //     for (int c = 0; c < old_pshape->multirow_tr_shape_up[r].size(); c++) {
                //         std::cout << old_pshape->multirow_tr_shape_up[r][c];
                //     }
                //     std::cout << std::endl;
                // }
                // std::cout << "--" << std::endl;
                // for (int r = 0; r < old_pshape->multirow_tr_shape_down.size(); r++) {
                //     for (int c = 0; c < old_pshape->multirow_tr_shape_down[r].size(); c++) {
                //         std::cout << old_pshape->multirow_tr_shape_down[r][c];
                //     }
                //     std::cout << std::endl;
                // }
                // std::cout << "multi_row_configs[current_tr].size(): " << multi_row_configs[current_tr].size() << std::endl;
                for (auto lamb : multi_row_configs[current_tr]) {
                    auto new_tr_permutation = old_pshape->tr_permutaton;
                    auto new_tr_shape_id = old_pshape->tr_shape_id;
                    auto new_ds_array = old_pshape->ds_array;
                    // std::cout << "new_lamb: " << std::endl;
                    // for (int r = 0; r < lamb->config_up.size(); r++) {
                    //     for (int c = 0; c < lamb->config_up[r].size(); c++) {
                    //         std::cout << lamb->config_up[r][c];
                    //     }
                    //     std::cout << std::endl;
                    // }
                    // std::cout << "--" << std::endl;
                    // for (int r = 0; r < lamb->config_down.size(); r++) {
                    //     for (int c = 0; c < lamb->config_down[r].size(); c++) {
                    //         std::cout << lamb->config_down[r][c];
                    //     }
                    //     std::cout << std::endl;
                    // }
                    for (int row = std::max(0, static_cast<int>(old_pshape->height - lamb->config_up.size())); row <= old_pshape->height; row++) {
                        int col;
                        if (row < old_pshape->multirow_tr_shape_up.size()) {
                            col = old_pshape->most_right_idx[row];
                        } else {
                            col = 0;
                        }
                        while (true) {
                            if (merge_enable(old_pshape, lamb, tr_pairs[current_tr], current_tr, row, col)) {
                                // std::cout << "row/col: " << row << " " << col << std::endl;
                                Pshape *pshape = merge(old_pshape, lamb, tr_pairs[current_tr], current_tr, row, col);
                                // cut by low_bound
                                // low_bound = pshape->multirow_area + tr_left_sum;
                                // low_bound = std::max(pshape->top_width + tr_left_sum, pshape->width) * pshape->height;
                                // low_bound = std::max(pshape->top_width + 2 + tr_left_sum, pshape->width + 2) * pshape->height;
                                low_bound = std::numeric_limits<int>::max();
                                for (int h = pshape->height; h <= max_allowable_cell_height; h++) {
                                    int _low_bound =
                                        std::max(pshape->width, (pshape->top_width + tr_left_sum + (h - pshape->height + 1) - 1) / (h - pshape->height + 1));
                                    _low_bound = _low_bound * h;
                                    // std::cout << "_low_bound: " << _low_bound << " h: " << h << std::endl;
                                    if (_low_bound < low_bound) {
                                        low_bound = _low_bound;
                                    }
                                }
                                // std::cout << "low_bound: " << low_bound << " tr_left_sum: " << tr_left_sum << std::endl;
                                // << min_potential_macro_area << std::endl; std::cout << "min_cell_area: " << min_cell_area << std::endl; std::cout
                                // << pshape->height << "/ " << max_allowable_cell_height << std::endl; std::cout << low_bound << " " <<
                                // min_cell_area + 1 << std::endl;
                                if (low_bound > target_area) {
                                    delete pshape;
                                    pshape = nullptr;
                                    break;
                                }
                                if (pshape->height > max_allowable_cell_height) {
                                    delete pshape;
                                    pshape = nullptr;
                                    break;
                                }
                                if (low_bound < min_potential_macro_area) {
                                    for (auto item : new_partial_placement) {
                                        delete item;
                                        item = nullptr;
                                    }
                                    new_partial_placement.clear();
                                    new_partial_placement.shrink_to_fit();
                                    min_potential_macro_area = low_bound;
                                    new_partial_placement.push_back(pshape);
                                } else if (low_bound == min_potential_macro_area) {
                                    new_partial_placement.push_back(pshape);
                                } else {
                                    delete pshape;
                                    pshape = nullptr;
                                }
                                break;
                            }
                            col++;
                        }
                    }
                }
            }
            n->partial_shapes = new_partial_placement;
            // remained_pmos.erase(std::remove(remained_pmos.begin(), remained_pmos.end(), current_tr), remained_pmos.end());
            for (auto it = remained_pmos.begin(); it != remained_pmos.end();) {
                if (*it == current_tr) {
                    it = remained_pmos.erase(it);  // 刪除元素並返回新的位置
                } else {
                    ++it;
                }
            }

            n->remained_pmos = remained_pmos;
            n->tr_left_sum = tr_left_sum;
            n->parent = current_node;
            n->tr = current_tr;
            n->fill = 0;
            current_node->children.push_back(n);
            current_node = n;
        }
    }
    // auto end_dfs = std::chrono::high_resolution_clock::now();
    // std::chrono::duration<double> elapsed_dfs = end_dfs - start_dfs;
    // std::cout << "DFS Time taken : " << elapsed_dfs.count() << " seconds" << std::endl;
    // std::cout << "placement_cand.size(): " << placement_cand.size() << std::endl;
    return placement_cand;
}

void placement_multi_row_search_tree_bottom_up() {
    std::vector<double> workload;
    workload.assign(16, 0);
    tr_size_sum = 0;
    int min_cell_area = std::numeric_limits<int>::max() - 1;
    int min_macro_area = std::numeric_limits<int>::max() - 1;

    for (Transistor *tr : pmos) {
        tr_size_sum = tr_size_sum + std::max(tr->num_finger, tr_pairs[tr]->num_finger);
    }

    int target_area = tr_size_sum;

    // assign shape to each transistor
    for (Transistor *tr : pmos) {
        std::vector<Lambda *> multi_row_config;
        for (auto _p_shape : phi_merged[tr]) {
            for (auto lamb : _p_shape.second) {
                multi_row_config.push_back(lamb);
            }
        }
        multi_row_configs.insert(std::make_pair(tr, multi_row_config));
    }

    while (final_placement_cand.size() == 0) {
        double max_dfs_time_taken = 0;
        auto start_while = std::chrono::high_resolution_clock::now();
        auto item = bfs_placement(target_area);
        if (item.second.size() != 0) {
            final_placement_cand = item.second;
            break;
        } else {
            auto node_to_be_processed = item.first;
#pragma omp parallel for schedule(dynamic)
            for (auto n : node_to_be_processed) {
                if (final_placement_cand.size() >= max_placement_size) continue;
                auto start_dfs = std::chrono::high_resolution_clock::now();
                int pshape_size = n->partial_shapes.size();
                auto new_placement_cand = dfs_placement(n, target_area);
                auto end_dfs = std::chrono::high_resolution_clock::now();
                std::chrono::duration<double> elapsed_dfs = end_dfs - start_dfs;
                std::cout << "DFS Time taken : " << elapsed_dfs.count() << " seconds #pshape: " << pshape_size << std::endl;
                max_dfs_time_taken = std::max(max_dfs_time_taken, elapsed_dfs.count());
                for (auto pshape : new_placement_cand) {
                    final_placement_cand.push_back(pshape);
                }
                int thread_id = omp_get_thread_num();
                workload[thread_id] += elapsed_dfs.count();
            }
            std::cout << "max_dfs_time_taken: " << max_dfs_time_taken << std::endl;
        }
        for (int i = 0; i < 16; i++) {
            std::cout << "core" << i << ": " << workload[i] << std::endl;
        }
        workload.assign(16, 0);
        target_area++;
        auto end_while = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed_while = end_while - start_while;
        std::cout << "Time taken : " << elapsed_while.count() << " seconds" << std::endl;
    }

    std::cout << "number of cell: " << final_placement_cand.size() << std::endl;
    // std::cout << "min_macro_area: " << min_macro_area << std::endl;
    int place_cand_id = 0;
    for (auto pshape : final_placement_cand) {
        std::cout << "min_macro_area: " << pshape->multirow_macro_area << std::endl;
        std::cout << "#" << place_cand_id << std::endl;
        // print transistor name
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                if (pshape->multirow_tr_permutation_up[i][j] == nullptr) {
                    std::cout << "     ";
                } else {
                    std::cout << std::left << std::setw(4) << pshape->multirow_tr_permutation_up[i][j]->name << " ";
                }
            }
            std::cout << std::endl;
        }
        std::cout << "--" << std::endl;
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                if (pshape->multirow_tr_permutation_down[i][j] == nullptr) {
                    std::cout << "     ";
                } else {
                    std::cout << std::left << std::setw(4) << pshape->multirow_tr_permutation_down[i][j]->name << " ";
                }
            }
            std::cout << std::endl;
        }
        // print active
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                Transistor *tr_n = pshape->multirow_tr_permutation_up[i][j];
                switch (pshape->multirow_tr_shape_up[i][j]) {
                    case 0:
                        std::cout << std::left << std::setw(7) << tr_n->drain->name << " " << std::left << std::setw(7) << tr_n->gate->name << " " << std::left
                                  << std::setw(7) << tr_n->source->name << " ";
                        break;
                    case 1:
                        std::cout << std::left << std::setw(7) << tr_n->source->name << " " << std::left << std::setw(7) << tr_n->gate->name << " " << std::left
                                  << std::setw(7) << tr_n->drain->name << " ";
                        break;
                    case 2:
                        std::cout << "------------------------";
                        break;
                }
            }
            std::cout << std::endl;
        }
        std::cout << "--" << std::endl;
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                Transistor *tr_p = pshape->multirow_tr_permutation_down[i][j];
                switch (pshape->multirow_tr_shape_down[i][j]) {
                    case 0:
                        std::cout << std::left << std::setw(7) << tr_p->drain->name << " " << std::left << std::setw(7) << tr_p->gate->name << " " << std::left
                                  << std::setw(7) << tr_p->source->name << " ";
                        break;
                    case 1:
                        std::cout << std::left << std::setw(7) << tr_p->source->name << " " << std::left << std::setw(7) << tr_p->gate->name << " " << std::left
                                  << std::setw(7) << tr_p->drain->name << " ";
                        break;
                    case 2:
                        std::cout << "------------------------";
                        break;
                }
            }
            std::cout << std::endl;
        }
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                std::cout << pshape->multirow_tr_shape_up[i][j];
            }
            std::cout << std::endl;
        }
        std::cout << "--" << std::endl;
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                std::cout << pshape->multirow_tr_shape_down[i][j];
            }
            std::cout << std::endl;
        }
        std::cout << std::endl;
        place_cand_id++;
    }
}

__global__ void dfs_kernel(Node_device *d_node_to_be_processed, int *d_ds_dict, Pshape *d_result, int target_area, int num_nodes, int num_pmos) {
    // printf("Thread %d is running\n", threadIdx.x);
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= num_nodes) return;
    d_node_to_be_processed[idx].id = idx * idx + 87;
    Node_device root_node = d_node_to_be_processed[idx];
    // printf("From GPU %d ds is %d\n", idx, d_node_to_be_processed[idx].id);

    // Node_device *stack;
    // cudaMalloc(&stack, sizeof(Node_device) * num_pmos);
    Node_device stack[20];
    int stackTop = 0;
    stack[stackTop++] = d_node_to_be_processed[idx]; 
    // printf("From GPU %d ds is %d\n", idx, stackTop);

    // int min_macro_area = std::numeric_limits<int>::max() - 1;
    // Pshape* placement_cand;
    // bool pruned = false;
    // Node root = *root_node.parent;
    // printf("From GPU %d ds is %d\n", idx, root_node.id);
    // printf("From GPU %d ds is %d\n", idx, d_node_to_be_processed[idx].id);
    // std::vector<Transistor*> remained_pmos(root_node->remained_pmos);
    // Transistor* current_tr = root_node->tr;
    // Node* current_node = root_node;

    // if (root_node->remained_pmos.size() == 0) {
    //     return root_node->partial_shapes;
    // }

    // while (true) {
    //     if (final_placement_cand.size() >= max_placement_size) {
    //         break;
    //     }
    //     if (pruned) {
    //         // std::cout << "pruned!" << std::endl;
    //         pruned = false;
    //         while (true) {
    //             Node* n = current_node->parent;
    //             for (auto pshape : current_node->partial_shapes) {
    //                 delete pshape;
    //             }
    //             delete current_node;
    //             current_node = n;
    //             current_tr = n->tr;
    //             if (((current_node->remained_pmos.size() == 0 || current_node->fill == current_node->remained_pmos.size() - 1) &&
    //                  (current_node != root)) == false) {
    //                 break;
    //             }
    //         }
    //         current_node->fill++;
    //         if (current_node == root) {
    //             break;
    //         }
    //     } else if (current_node->remained_pmos.size() == 0) {
    //         // std::cout << "leaf!" << std::endl;
    //         if (current_node->partial_shapes.size() != 0) {
    //             for (auto pshape : current_node->partial_shapes) {
    //                 if (pshape->multirow_macro_area < min_macro_area) {
    //                     min_macro_area = pshape->multirow_macro_area;
    //                     for (auto item : placement_cand) {
    //                         delete item;
    //                         item = nullptr;
    //                     }
    //                     placement_cand.clear();
    //                     placement_cand.shrink_to_fit();
    //                     placement_cand.push_back(pshape);
    //                 } else if (pshape->multirow_macro_area == min_macro_area) {
    //                     placement_cand.push_back(pshape);
    //                 } else {
    //                     delete pshape;
    //                     pshape = nullptr;
    //                 }
    //                 if (placement_cand.size() >= max_placement_size) {
    //                     break;
    //                 }
    //             }
    //             // std::cout << "placement_cand.size(): " << placement_cand.size() << std::endl;
    //         } else {
    //             delete current_node;
    //         }
    //         if (placement_cand.size() >= max_placement_size) {
    //             break;
    //         }
    //         while ((current_node->remained_pmos.size() == 0 || current_node->fill == current_node->remained_pmos.size() - 1) &&
    //                (current_node != root)) {
    //             Node* n = current_node->parent;
    //             // tr_left_sum = tr_left_sum + std::max(current_tr->num_finger, tr_pairs[current_tr]->num_finger);
    //             current_node = n;
    //             current_tr = n->tr;
    //         }
    //         current_node->fill++;
    //         if (current_node == root) {
    //             break;
    //         }
    //     } else {
    //         int min_potential_macro_area = std::numeric_limits<int>::max();
    //         if (current_node->partial_shapes.size() == 0) {
    //             current_node->partial_shapes.clear();
    //             current_node->partial_shapes.shrink_to_fit();
    //             pruned = true;
    //             continue;
    //         }
    //         Node* n = new Node();
    //         std::vector<Transistor*> remained_pmos = current_node->remained_pmos;
    //         Transistor* old_tr = current_tr;
    //         current_tr = remained_pmos[current_node->fill];
    //         std::vector<Pshape*> new_partial_placement;
    //         int low_bound;
    //         int tr_left_sum = current_node->tr_left_sum - std::max(current_tr->num_finger, tr_pairs[current_tr]->num_finger);
    //         for (auto old_pshape : current_node->partial_shapes) {
    //             // std::cout << "old_pshape: " << std::endl;
    //             // for (int r = 0; r < old_pshape->multirow_tr_shape_up.size(); r++) {
    //             //     for (int c = 0; c < old_pshape->multirow_tr_shape_up[r].size(); c++) {
    //             //         std::cout << old_pshape->multirow_tr_shape_up[r][c];
    //             //     }
    //             //     std::cout << std::endl;
    //             // }
    //             // std::cout << "--" << std::endl;
    //             // for (int r = 0; r < old_pshape->multirow_tr_shape_down.size(); r++) {
    //             //     for (int c = 0; c < old_pshape->multirow_tr_shape_down[r].size(); c++) {
    //             //         std::cout << old_pshape->multirow_tr_shape_down[r][c];
    //             //     }
    //             //     std::cout << std::endl;
    //             // }
    //             // std::cout << "multi_row_configs[current_tr].size(): " << multi_row_configs[current_tr].size() << std::endl;
    //             for (auto lamb : multi_row_configs[current_tr]) {
    //                 auto new_tr_permutation = old_pshape->tr_permutaton;
    //                 auto new_tr_shape_id = old_pshape->tr_shape_id;
    //                 auto new_ds_array = old_pshape->ds_array;
    //                 // std::cout << "new_lamb: " << std::endl;
    //                 // for (int r = 0; r < lamb->config_up.size(); r++) {
    //                 //     for (int c = 0; c < lamb->config_up[r].size(); c++) {
    //                 //         std::cout << lamb->config_up[r][c];
    //                 //     }
    //                 //     std::cout << std::endl;
    //                 // }
    //                 // std::cout << "--" << std::endl;
    //                 // for (int r = 0; r < lamb->config_down.size(); r++) {
    //                 //     for (int c = 0; c < lamb->config_down[r].size(); c++) {
    //                 //         std::cout << lamb->config_down[r][c];
    //                 //     }
    //                 //     std::cout << std::endl;
    //                 // }
    //                 for (int row = std::max(0, static_cast<int>(old_pshape->height - lamb->config_up.size())); row <= old_pshape->height; row++) {
    //                     int col;
    //                     if (row < old_pshape->multirow_tr_shape_up.size()) {
    //                         col = old_pshape->most_right_idx[row];
    //                     } else {
    //                         col = 0;
    //                     }
    //                     while (true) {
    //                         if (merge_enable(old_pshape, lamb, tr_pairs[current_tr], current_tr, row, col)) {
    //                             // std::cout << "row/col: " << row << " " << col << std::endl;
    //                             Pshape* pshape = merge(old_pshape, lamb, tr_pairs[current_tr], current_tr, row, col);
    //                             // cut by low_bound
    //                             // low_bound = pshape->multirow_area + tr_left_sum;
    //                             // low_bound = std::max(pshape->top_width + tr_left_sum, pshape->width) * pshape->height;
    //                             // low_bound = std::max(pshape->top_width + 2 + tr_left_sum, pshape->width + 2) * pshape->height;
    //                             low_bound = std::numeric_limits<int>::max();
    //                             for (int h = pshape->height; h <= max_allowable_cell_height; h++) {
    //                                 int _low_bound = std::max(
    //                                     pshape->width, (pshape->top_width + tr_left_sum + (h - pshape->height + 1) - 1) / (h - pshape->height + 1));
    //                                 _low_bound = _low_bound * h;
    //                                 // std::cout << "_low_bound: " << _low_bound << " h: " << h << std::endl;
    //                                 if (_low_bound < low_bound) {
    //                                     low_bound = _low_bound;
    //                                 }
    //                             }
    //                             // std::cout << "low_bound: " << low_bound << " tr_left_sum: " << tr_left_sum << std::endl;
    //                             // << min_potential_macro_area << std::endl; std::cout << "min_cell_area: " << min_cell_area << std::endl; std::cout
    //                             // << pshape->height << "/ " << max_allowable_cell_height << std::endl; std::cout << low_bound << " " <<
    //                             // min_cell_area + 1 << std::endl;
    //                             if (low_bound > target_area) {
    //                                 delete pshape;
    //                                 pshape = nullptr;
    //                                 break;
    //                             }
    //                             if (pshape->height > max_allowable_cell_height) {
    //                                 delete pshape;
    //                                 pshape = nullptr;
    //                                 break;
    //                             }
    //                             if (low_bound < min_potential_macro_area) {
    //                                 for (auto item : new_partial_placement) {
    //                                     delete item;
    //                                     item = nullptr;
    //                                 }
    //                                 new_partial_placement.clear();
    //                                 new_partial_placement.shrink_to_fit();
    //                                 min_potential_macro_area = low_bound;
    //                                 new_partial_placement.push_back(pshape);
    //                             } else if (low_bound == min_potential_macro_area) {
    //                                 new_partial_placement.push_back(pshape);
    //                             } else {
    //                                 delete pshape;
    //                                 pshape = nullptr;
    //                             }
    //                             break;
    //                         }
    //                         col++;
    //                     }
    //                 }
    //             }
    //         }
    //         n->partial_shapes = new_partial_placement;
    //         // remained_pmos.erase(std::remove(remained_pmos.begin(), remained_pmos.end(), current_tr), remained_pmos.end());
    //         for (auto it = remained_pmos.begin(); it != remained_pmos.end();) {
    //             if (*it == current_tr) {
    //                 it = remained_pmos.erase(it);  // 刪除元素並返回新的位置
    //             } else {
    //                 ++it;
    //             }
    //         }

    //         n->remained_pmos = remained_pmos;
    //         n->tr_left_sum = tr_left_sum;
    //         n->parent = current_node;
    //         n->tr = current_tr;
    //         n->fill = 0;
    //         current_node->children.push_back(n);
    //         current_node = n;
    //     }
    // }
    // std::cout << "placement_cand.size(): " << placement_cand.size() << std::endl;
    // return placement_cand;
}

// void placement_single_row_search_tree_bottom_up() {
//     dfs_kernel<<<1, 100>>>();

//     // Check for any kernel launch errors
//     // cudaError_t err = cudaGetLastError();
//     // if (err != cudaSuccess) {
//     //     std::cerr << "CUDA error: " << cudaGetErrorString(err) << std::endl;
//     // }

//     // // Synchronize to ensure kernel finishes before continuing
//     cudaDeviceSynchronize();

//     // Final error check after synchronization
//     // err = cudaGetLastError();
//     // if (err != cudaSuccess) {
//     //     std::cerr << "CUDA error after synchronization: " << cudaGetErrorString(err) << std::endl;
//     // }
// }

void placement_single_row_search_tree_bottom_up() {
    for (Transistor *p : pmos) {
        Transistor *n = tr_pairs[p];
        p->num_finger = (p->width - 0.1) / max_cfet_width + 1;
        n->num_finger = (n->width - 0.1) / max_cfet_width + 1;
    }

    tr_size_sum = 0;
    int min_cell_area = std::numeric_limits<int>::max() - 1;
    int min_macro_area = std::numeric_limits<int>::max() - 1;

    for (Transistor *tr : pmos) {
        tr_size_sum = tr_size_sum + std::max(tr->num_finger, tr_pairs[tr]->num_finger);
    }

    // initial target_area
    int target_area = tr_size_sum;

    // assign shape to each transistor
    for (Transistor *tr : pmos) {
        std::cout << tr->name << std::endl;
        std::vector<Lambda *> multi_row_config;
        for (auto _p_shape : phi_merged[tr]) {
            tr->lamb_id = new int[_p_shape.second.size()];
            tr->lamb_size = _p_shape.second.size();
            int _idx = 0;
            for (auto lamb : _p_shape.second) {
                multi_row_config.push_back(lamb);
                lamb->id = lamb_id;
                lamb->tr = tr;
                lambda_dict.insert(std::make_pair(lamb->id, lamb));
                tr->lamb_id[_idx] = lamb_id;
                lamb_id++;
                _idx++;
            }
        }
        multi_row_configs.insert(std::make_pair(tr, multi_row_config));
    }
    std::cout << "id size: " << lamb_id << std::endl;
    ds_dict = new int[lamb_id * lamb_id];
    for (int i = 0; i < lamb_id; i++) {
        for (int j = 0; j < lamb_id; j++) {
            Lambda *lamb_left = lambda_dict[i];
            Lambda *lamb_right = lambda_dict[j];
            Signal *up_left_sig = get_right_active(lamb_left->tr, lamb_left->config_up[0][lamb_left->config_up[0].size() - 1]);
            Signal *up_right_sig = get_left_active(lamb_right->tr, lamb_right->config_up[0][0]);
            Signal *down_left_sig = get_right_active(tr_pairs[lamb_left->tr], lamb_left->config_down[0][lamb_left->config_down[0].size() - 1]);
            Signal *down_right_sig = get_left_active(tr_pairs[lamb_right->tr], lamb_right->config_down[0][0]);
            if (up_left_sig == nullptr || up_right_sig == nullptr) {
                if (down_left_sig == nullptr || down_right_sig == nullptr) {
                    ds_dict[i * lamb_id + j] = 1;
                } else if (down_left_sig == down_right_sig) {
                    ds_dict[i * lamb_id + j] = 1;
                } else {
                    ds_dict[i * lamb_id + j] = 0;
                }
            } else if (up_left_sig == up_right_sig) {
                if (down_left_sig == nullptr || down_right_sig == nullptr) {
                    ds_dict[i * lamb_id + j] = 1;
                } else if (down_left_sig == down_right_sig) {
                    ds_dict[i * lamb_id + j] = 1;
                } else {
                    ds_dict[i * lamb_id + j] = 0;
                }
            } else {
                ds_dict[i * lamb_id + j] = 0;
            }
        }
    }

    for (int i = 0; i < lamb_id; i++) {
        for (int j = 0; j < lamb_id; j++) {
            std::cout << ds_dict[i * lamb_id + j];
        }
        std::cout << std::endl;
    }

    while (final_placement_cand.size() == 0) {
        auto start_while = std::chrono::high_resolution_clock::now();
        auto item = bfs_placement_singlerow(target_area);
        std::cout << "item: " << item.first.size() << " " << item.second.size() << std::endl;
        std::vector<Node_device> node_to_be_processed;
        const int N = item.first.size();
        if (N != 0) { // need dfs kernel
            for (int i = 0; i < N; i++) {
                Node n = *item.first[i];
                Node_device nd(pmos.size());
                node_to_be_processed.push_back(nd);
                
            }
        }
        else {
            break;
        }
        //     Node_device node_to_be_processed[item.first.size()];
        Node_device* d_node_to_be_processed;
        int* d_ds_dict;
        //     Pshape result[num_nodes_parsed_to_gpu];
        Pshape* d_result;

        //     for (int i = 0; i < item.first.size(); i++) {
        //         Node_device n;
        //         n.id = 87;
        //         node_to_be_processed[i] = n;
        //     }

        cudaMalloc(&d_node_to_be_processed, sizeof(Node_device) * N);
        cudaMalloc(&d_ds_dict, sizeof(int) * lamb_id * lamb_id);
        cudaMalloc(&d_result, sizeof(Pshape) * N);

        cudaMemcpy(d_node_to_be_processed, node_to_be_processed.data(), sizeof(Node_device) * N, cudaMemcpyHostToDevice);
        cudaMemcpy(d_ds_dict, ds_dict, sizeof(int) * lamb_id * lamb_id, cudaMemcpyHostToDevice);

        dim3 gridDim(1);
        dim3 blockDim(100);
        // std::cout << "start dfs_kernel" << std::endl;
        dfs_kernel<<<gridDim, blockDim>>>(d_node_to_be_processed, d_ds_dict, d_result, target_area, N, pmos.size());
        // dfs_kernel<<<1, 100>>>();

        cudaDeviceSynchronize();

        //     cudaMemcpy(node_to_be_processed, d_node_to_be_processed, sizeof(Node_device) * num_nodes_parsed_to_gpu, cudaMemcpyDeviceToHost);

        //     cudaMemcpy(result, d_result, sizeof(Pshape) * num_nodes_parsed_to_gpu, cudaMemcpyDeviceToHost);

        //     int total_result = 0;
        //     for (int i = 0; i < num_nodes_parsed_to_gpu; i++) {
        //         // if (result[i] != nullptr) {
        //         //     std::cout << "i: " << i << std::endl;
        //         //     std::cout << result[i]->width << std::endl;
        //         //     total_result++;
        //         // }
        //         std::cout << i << " " << node_to_be_processed[i].id << std::endl;
        //     }
        //     std::cout << "total result: " << total_result << std::endl;

        //     // Free device memory
        //     cudaFree(d_node_to_be_processed);
        //     // cudaFree(d_ds_dict);

        //     // Free host memory
        //     // free(result);

            // break;
        // }
        target_area++;
        auto end_while = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed_while = end_while - start_while;
        std::cout << "Time taken : " << elapsed_while.count() << " seconds" << std::endl;
        break;
    }

    // std::cout << "number of cell: " << final_placement_cand.size() << std::endl;
    // // std::cout << "min_macro_area: " << min_macro_area << std::endl;
    // int place_cand_id = 0;
    // for (auto pshape : final_placement_cand) {
    //     std::cout << "min_macro_area: " << pshape->multirow_macro_area << std::endl;
    //     std::cout << "#" << place_cand_id << std::endl;
    //     // print transistor name
    //     for (int i = 0; i < pshape->height; i++) {
    //         for (int j = 0; j < pshape->width; j++) {
    //             if (pshape->multirow_tr_permutation_up[i][j] == nullptr) {
    //                 std::cout << "     ";
    //             } else {
    //                 std::cout << std::left << std::setw(4) << pshape->multirow_tr_permutation_up[i][j]->name << " ";
    //             }
    //         }
    //         std::cout << std::endl;
    //     }
    //     std::cout << "--" << std::endl;
    //     for (int i = 0; i < pshape->height; i++) {
    //         for (int j = 0; j < pshape->width; j++) {
    //             if (pshape->multirow_tr_permutation_down[i][j] == nullptr) {
    //                 std::cout << "     ";
    //             } else {
    //                 std::cout << std::left << std::setw(4) << pshape->multirow_tr_permutation_down[i][j]->name << " ";
    //             }
    //         }
    //         std::cout << std::endl;
    //     }
    //     // print active
    //     for (int i = 0; i < pshape->height; i++) {
    //         for (int j = 0; j < pshape->width; j++) {
    //             Transistor *tr_n = pshape->multirow_tr_permutation_up[i][j];
    //             switch (pshape->multirow_tr_shape_up[i][j]) {
    //                 case 0:
    //                     std::cout << std::left << std::setw(7) << tr_n->drain->name << " " << std::left << std::setw(7) << tr_n->gate->name << " " << std::left
    //                               << std::setw(7) << tr_n->source->name << " ";
    //                     break;
    //                 case 1:
    //                     std::cout << std::left << std::setw(7) << tr_n->source->name << " " << std::left << std::setw(7) << tr_n->gate->name << " " << std::left
    //                               << std::setw(7) << tr_n->drain->name << " ";
    //                     break;
    //                 case 2:
    //                     std::cout << "------------------------";
    //                     break;
    //             }
    //         }
    //         std::cout << std::endl;
    //     }
    //     std::cout << "--" << std::endl;
    //     for (int i = 0; i < pshape->height; i++) {
    //         for (int j = 0; j < pshape->width; j++) {
    //             Transistor *tr_p = pshape->multirow_tr_permutation_down[i][j];
    //             switch (pshape->multirow_tr_shape_down[i][j]) {
    //                 case 0:
    //                     std::cout << std::left << std::setw(7) << tr_p->drain->name << " " << std::left << std::setw(7) << tr_p->gate->name << " " << std::left
    //                               << std::setw(7) << tr_p->source->name << " ";
    //                     break;
    //                 case 1:
    //                     std::cout << std::left << std::setw(7) << tr_p->source->name << " " << std::left << std::setw(7) << tr_p->gate->name << " " << std::left
    //                               << std::setw(7) << tr_p->drain->name << " ";
    //                     break;
    //                 case 2:
    //                     std::cout << "------------------------";
    //                     break;
    //             }
    //         }
    //         std::cout << std::endl;
    //     }
    //     for (int i = 0; i < pshape->height; i++) {
    //         for (int j = 0; j < pshape->width; j++) {
    //             std::cout << pshape->multirow_tr_shape_up[i][j];
    //         }
    //         std::cout << std::endl;
    //     }
    //     std::cout << "--" << std::endl;
    //     for (int i = 0; i < pshape->height; i++) {
    //         for (int j = 0; j < pshape->width; j++) {
    //             std::cout << pshape->multirow_tr_shape_down[i][j];
    //         }
    //         std::cout << std::endl;
    //     }
    //     std::cout << std::endl;
    //     place_cand_id++;
    // }
}