#include <cuda_runtime.h>
#include <omp.h>
#include <sys/stat.h>  // Linux/Unix 系統用於創建資料夾

#include <algorithm>
#include <cassert>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <mutex>
#include <queue>
#include <set>
#include <sstream>
#include <unordered_map>
#include <vector>

#include "cfet.h"

namespace fs = std::filesystem;

int createFolder(const std::string &folderName) {
#ifdef _WIN32
    return _mkdir(folderName.c_str());  // Windows 系統
#else
    return mkdir(folderName.c_str(), 0777);  // Linux/Unix 系統
#endif
}

std::pair<std::vector<Node *>, std::vector<Pshape *>> bfs_placement(int target_area) {
    std::vector<Pshape *> placement_cand;
    std::cout << "target_area: " << target_area << std::endl;
    std::queue<Node *> q;
    Node *root = new Node();
    std::vector<Transistor *> remained_pmos(pmos);
    root->name = "root";
    root->remained_pmos = remained_pmos;
    root->tr_left_sum = tr_size_sum;
    Transistor *root_tr = new Transistor();
    root_tr->name = "root_tr";
    root->tr = root_tr;
    q.push(root);
    while (q.empty() == false) {
        // std::cout << "q.size(): " << q.size() << std::endl;
        if (q.size() >= num_nodes_parsed_to_gpu) {
            std::vector<Node *> node_to_be_processed;
            while (q.empty() == false) {
                Node *n = q.front();
                node_to_be_processed.push_back(n);
                q.pop();
            }
            return std::make_pair(node_to_be_processed, std::vector<Pshape *>());
        }
        if (placement_cand.size() >= max_placement_size) {
            break;
        }
        Node *current_node = q.front();
        // branch
        // std::cout << "current_node->remained_pmos.size(): " << current_node->remained_pmos.size() << std::endl;
        if (current_node->remained_pmos.size() != 0) {
            // #pragma omp parallel for schedule(dynamic)
            for (Transistor *br_tr : current_node->remained_pmos) {
                Node *br_node = new Node();
                std::vector<Transistor *> remained_pmos(current_node->remained_pmos);
                for (auto it = remained_pmos.begin(); it != remained_pmos.end();) {
                    if (*it == br_tr) {
                        it = remained_pmos.erase(it);  // 刪除元素並返回新的位置
                    } else {
                        ++it;
                    }
                }
                br_node->parent = current_node;
                br_node->remained_pmos = remained_pmos;
                br_node->tr = br_tr;
                br_node->tr_left_sum = current_node->tr_left_sum - std::max(br_tr->num_finger, tr_pairs[br_tr]->num_finger);
                // create partial shape
                if (current_node->name == "root") {
                    std::vector<Pshape *> partial_placement;
                    for (auto lamb : multi_row_configs[br_tr]) {
                        Pshape *pshape = new Pshape();
                        // multi-row
                        pshape->multirow_area = std::max(br_tr->num_finger, tr_pairs[br_tr]->num_finger);
                        pshape->multirow_tr_shape_up = lamb->config_up;
                        pshape->multirow_tr_shape_down = lamb->config_down;
                        pshape->multirow_tr_permutation_up.assign(lamb->config_up.size(), std::vector<Transistor *>(lamb->config_up[0].size()));
                        pshape->multirow_tr_permutation_down.assign(lamb->config_down.size(), std::vector<Transistor *>(lamb->config_down[0].size()));
                        pshape->height = 0;
                        pshape->width = 0;
                        pshape->top_width = 0;
                        for (int row = 0; row < lamb->config_up.size(); row++) {
                            pshape->most_right_idx.push_back(0);
                            for (int col = 0; col < lamb->config_up[row].size(); col++) {
                                if (lamb->config_up[row][col] != 2) {
                                    pshape->multirow_tr_permutation_up[row][col] = tr_pairs[br_tr];
                                    pshape->most_right_idx[row] = col;
                                    pshape->height = row + 1;
                                } else {
                                    pshape->multirow_tr_permutation_up[row][col] = nullptr;
                                }
                                if (lamb->config_down[row][col] != 2) {
                                    pshape->multirow_tr_permutation_down[row][col] = br_tr;
                                    pshape->most_right_idx[row] = col;
                                    pshape->height = row + 1;
                                } else {
                                    pshape->multirow_tr_permutation_down[row][col] = nullptr;
                                }
                                if (lamb->config_up[row][col] != 2 || lamb->config_down[row][col] != 2) {
                                    if (col + 1 > pshape->width) {
                                        pshape->width = col + 1;
                                    }
                                }
                            }
                            if (row == lamb->config_up.size() - 1) {
                                for (int col = 0; col < lamb->config_up[row].size(); col++) {
                                    if (lamb->config_up[row][col] != 2 || lamb->config_down[row][col] != 2) {
                                        pshape->top_width = col + 1;
                                    }
                                }
                            }
                        }
                        pshape->multirow_macro_area = (pshape->width) * pshape->height;
                        // for (int i = 0; i < pshape->multirow_tr_permutation_up.size(); i++) {
                        //     for (int j = 0; j < pshape->multirow_tr_permutation_up[i].size(); j++) {
                        //         if (pshape->multirow_tr_permutation_up[i][j] == nullptr) std::cout << "  x ";
                        //         else std::cout << pshape->multirow_tr_permutation_up[i][j]->name << " ";
                        //     }
                        //     std::cout << std::endl;
                        // }
                        // std::cout << "--" << std::endl;
                        // for (int i = 0; i < pshape->multirow_tr_permutation_down.size(); i++) {
                        //     for (int j = 0; j < pshape->multirow_tr_permutation_down[i].size(); j++) {
                        //         if (pshape->multirow_tr_permutation_down[i][j] == nullptr) std::cout << "  x ";
                        //         else std::cout << pshape->multirow_tr_permutation_down[i][j]->name << " ";
                        //     }
                        //     std::cout << std::endl;
                        // }
                        // std::cout << std::endl;
                        partial_placement.push_back(pshape);
                    }
                    // assign partial_placement
                    br_node->partial_shapes = partial_placement;
                } else {
                    int min_potential_macro_area = std::numeric_limits<int>::max();
                    std::vector<Pshape *> new_partial_placement;
                    for (auto old_pshape : current_node->partial_shapes) {
                        for (auto lamb : multi_row_configs[br_tr]) {
                            auto new_tr_permutation = old_pshape->tr_permutaton;
                            auto new_tr_shape_id = old_pshape->tr_shape_id;
                            auto new_ds_array = old_pshape->ds_array;
                            for (int row = std::max(0, static_cast<int>(old_pshape->height - lamb->config_up.size())); row <= old_pshape->height; row++) {
                                int col;
                                if (row < old_pshape->multirow_tr_shape_up.size()) {
                                    col = old_pshape->most_right_idx[row];
                                } else {
                                    col = 0;
                                }
                                while (true) {
                                    if (merge_enable(old_pshape, lamb, tr_pairs[br_tr], br_tr, row, col)) {
                                        Pshape *pshape = merge(old_pshape, lamb, tr_pairs[br_tr], br_tr, row, col);
                                        if (pshape->height > max_allowable_cell_height) {
                                            delete pshape;
                                            pshape = nullptr;
                                            break;
                                        }
                                        int low_bound = std::numeric_limits<int>::max();
                                        for (int h = pshape->height; h <= max_allowable_cell_height; h++) {
                                            int _low_bound = std::max(pshape->width, (pshape->top_width + br_node->tr_left_sum + (h - pshape->height + 1) - 1) /
                                                                                         (h - pshape->height + 1));
                                            _low_bound = _low_bound * h;
                                            if (_low_bound < low_bound) {
                                                low_bound = _low_bound;
                                            }
                                        }
                                        // for (int i = 0; i < pshape->multirow_tr_permutation_up.size(); i++) {
                                        //     for (int j = 0; j < pshape->multirow_tr_permutation_up[i].size(); j++) {
                                        //         if (pshape->multirow_tr_permutation_up[i][j] == nullptr) std::cout << "  x ";
                                        //         else std::cout << pshape->multirow_tr_permutation_up[i][j]->name << " ";
                                        //     }
                                        //     std::cout << std::endl;
                                        // }
                                        // std::cout << "--" << std::endl;
                                        // for (int i = 0; i < pshape->multirow_tr_permutation_down.size(); i++) {
                                        //     for (int j = 0; j < pshape->multirow_tr_permutation_down[i].size(); j++) {
                                        //         if (pshape->multirow_tr_permutation_down[i][j] == nullptr) std::cout << "  x ";
                                        //         else std::cout << pshape->multirow_tr_permutation_down[i][j]->name << " ";
                                        //     }
                                        //     std::cout << std::endl;
                                        // }
                                        // std::cout << "current_node->tr_left_sum: " << current_node->tr_left_sum << std::endl;
                                        // std::cout << "low_bound: " << low_bound << std::endl;
                                        // std::cout << std::endl;
                                        if (low_bound > target_area) {
                                            delete pshape;
                                            pshape = nullptr;
                                            break;
                                        }
                                        if (low_bound < min_potential_macro_area) {
                                            for (auto item : new_partial_placement) {
                                                delete item;
                                                item = nullptr;
                                            }
                                            new_partial_placement.clear();
                                            new_partial_placement.shrink_to_fit();
                                            min_potential_macro_area = low_bound;
                                            new_partial_placement.push_back(pshape);
                                        } else if (low_bound == min_potential_macro_area) {
                                            new_partial_placement.push_back(pshape);
                                        } else {
                                            delete pshape;
                                            pshape = nullptr;
                                        }
                                        break;
                                    }
                                    col++;
                                }
                            }
                        }
                    }
                    br_node->partial_shapes = new_partial_placement;
                }
                if (br_node->partial_shapes.size() != 0) {
                    q.push(br_node);
                } else {
                    delete br_node;
                    br_node = nullptr;
                }
            }

            for (auto pshape : current_node->partial_shapes) {
                delete pshape;
                pshape = nullptr;
            }
            // delete current_node;
            // current_node = nullptr;
        } else {  // leaf
            for (auto pshape : current_node->partial_shapes) {
                if (placement_cand.size() < max_placement_size) {
                    if (pshape->multirow_macro_area <= target_area) {
                        // std::cout << "pshape->multirow_macro_area: " << pshape->multirow_macro_area << std::endl;
                        // for (int i = 0; i < pshape->multirow_tr_permutation_up.size(); i++) {
                        //     for (int j = 0; j < pshape->multirow_tr_permutation_up[i].size(); j++) {
                        //         std::cout << pshape->multirow_tr_permutation_up[i][j]->name << " ";
                        //     }
                        //     std::cout << std::endl;
                        // }
                        // std::cout << "--" << std::endl;
                        // for (int i = 0; i < pshape->multirow_tr_permutation_down.size(); i++) {
                        //     for (int j = 0; j < pshape->multirow_tr_permutation_down[i].size(); j++) {
                        //         std::cout << pshape->multirow_tr_permutation_down[i][j]->name << " ";
                        //     }
                        //     std::cout << std::endl;
                        // }
                        placement_cand.push_back(pshape);
                    } else {
                        delete pshape;
                        pshape = nullptr;
                    }
                } else {
                    break;
                }
            }
            // delete current_node;
            // current_node = nullptr;
        }
        // std::cout << "placement_cand.size(): " << placement_cand.size() << std::endl;
        if (placement_cand.size() >= max_placement_size) {
            break;
        }
        q.pop();
    }
    return std::make_pair(std::vector<Node *>(), placement_cand);
}

std::vector<Pshape *> dfs_placement(Node *root_node, int target_area) {
    // std::cout << "dfs" << std::endl;
    // auto start_dfs = std::chrono::high_resolution_clock::now();
    int min_macro_area = std::numeric_limits<int>::max() - 1;
    std::vector<Pshape *> placement_cand;
    bool pruned = false;
    Node *root = root_node->parent;
    std::vector<Transistor *> remained_pmos(root_node->remained_pmos);
    Transistor *current_tr = root_node->tr;
    Node *current_node = root_node;

    if (root_node->remained_pmos.size() == 0) {
        return root_node->partial_shapes;
    }

    while (true) {
        if (final_placement_cand.size() >= max_placement_size) {
            break;
        }
        if (pruned) {
            // std::cout << "pruned!" << std::endl;
            pruned = false;
            while (true) {
                Node *n = current_node->parent;
                for (auto pshape : current_node->partial_shapes) {
                    delete pshape;
                }
                delete current_node;
                current_node = n;
                current_tr = n->tr;
                if (((current_node->remained_pmos.size() == 0 || current_node->fill == current_node->remained_pmos.size() - 1) && (current_node != root)) ==
                    false) {
                    break;
                }
            }
            current_node->fill++;
            if (current_node == root) {
                break;
            }
        } else if (current_node->remained_pmos.size() == 0) {
            // std::cout << "leaf!" << std::endl;
            if (current_node->partial_shapes.size() != 0) {
                for (auto pshape : current_node->partial_shapes) {
                    if (pshape->multirow_macro_area < min_macro_area) {
                        min_macro_area = pshape->multirow_macro_area;
                        for (auto item : placement_cand) {
                            delete item;
                            item = nullptr;
                        }
                        placement_cand.clear();
                        placement_cand.shrink_to_fit();
                        placement_cand.push_back(pshape);
                    } else if (pshape->multirow_macro_area == min_macro_area) {
                        placement_cand.push_back(pshape);
                    } else {
                        delete pshape;
                        pshape = nullptr;
                    }
                    if (placement_cand.size() >= max_placement_size) {
                        break;
                    }
                }
                // std::cout << "placement_cand.size(): " << placement_cand.size() << std::endl;
            } else {
                delete current_node;
            }
            if (placement_cand.size() >= max_placement_size) {
                break;
            }
            while ((current_node->remained_pmos.size() == 0 || current_node->fill == current_node->remained_pmos.size() - 1) && (current_node != root)) {
                Node *n = current_node->parent;
                // tr_left_sum = tr_left_sum + std::max(current_tr->num_finger, tr_pairs[current_tr]->num_finger);
                current_node = n;
                current_tr = n->tr;
            }
            current_node->fill++;
            if (current_node == root) {
                break;
            }
        } else {
            int min_potential_macro_area = std::numeric_limits<int>::max();
            if (current_node->partial_shapes.size() == 0) {
                current_node->partial_shapes.clear();
                current_node->partial_shapes.shrink_to_fit();
                pruned = true;
                continue;
            }
            Node *n = new Node();
            std::vector<Transistor *> remained_pmos = current_node->remained_pmos;
            Transistor *old_tr = current_tr;
            current_tr = remained_pmos[current_node->fill];
            std::vector<Pshape *> new_partial_placement;
            int low_bound;
            int tr_left_sum = current_node->tr_left_sum - std::max(current_tr->num_finger, tr_pairs[current_tr]->num_finger);
            for (auto old_pshape : current_node->partial_shapes) {
                // std::cout << "old_pshape: " << std::endl;
                // for (int r = 0; r < old_pshape->multirow_tr_shape_up.size(); r++) {
                //     for (int c = 0; c < old_pshape->multirow_tr_shape_up[r].size(); c++) {
                //         std::cout << old_pshape->multirow_tr_shape_up[r][c];
                //     }
                //     std::cout << std::endl;
                // }
                // std::cout << "--" << std::endl;
                // for (int r = 0; r < old_pshape->multirow_tr_shape_down.size(); r++) {
                //     for (int c = 0; c < old_pshape->multirow_tr_shape_down[r].size(); c++) {
                //         std::cout << old_pshape->multirow_tr_shape_down[r][c];
                //     }
                //     std::cout << std::endl;
                // }
                // std::cout << "multi_row_configs[current_tr].size(): " << multi_row_configs[current_tr].size() << std::endl;
                for (auto lamb : multi_row_configs[current_tr]) {
                    auto new_tr_permutation = old_pshape->tr_permutaton;
                    auto new_tr_shape_id = old_pshape->tr_shape_id;
                    auto new_ds_array = old_pshape->ds_array;
                    // std::cout << "new_lamb: " << std::endl;
                    // for (int r = 0; r < lamb->config_up.size(); r++) {
                    //     for (int c = 0; c < lamb->config_up[r].size(); c++) {
                    //         std::cout << lamb->config_up[r][c];
                    //     }
                    //     std::cout << std::endl;
                    // }
                    // std::cout << "--" << std::endl;
                    // for (int r = 0; r < lamb->config_down.size(); r++) {
                    //     for (int c = 0; c < lamb->config_down[r].size(); c++) {
                    //         std::cout << lamb->config_down[r][c];
                    //     }
                    //     std::cout << std::endl;
                    // }
                    for (int row = std::max(0, static_cast<int>(old_pshape->height - lamb->config_up.size())); row <= old_pshape->height; row++) {
                        int col;
                        if (row < old_pshape->multirow_tr_shape_up.size()) {
                            col = old_pshape->most_right_idx[row];
                        } else {
                            col = 0;
                        }
                        while (true) {
                            if (merge_enable(old_pshape, lamb, tr_pairs[current_tr], current_tr, row, col)) {
                                // std::cout << "row/col: " << row << " " << col << std::endl;
                                Pshape *pshape = merge(old_pshape, lamb, tr_pairs[current_tr], current_tr, row, col);
                                // cut by low_bound
                                // low_bound = pshape->multirow_area + tr_left_sum;
                                // low_bound = std::max(pshape->top_width + tr_left_sum, pshape->width) * pshape->height;
                                // low_bound = std::max(pshape->top_width + 2 + tr_left_sum, pshape->width + 2) * pshape->height;
                                low_bound = std::numeric_limits<int>::max();
                                for (int h = pshape->height; h <= max_allowable_cell_height; h++) {
                                    int _low_bound =
                                        std::max(pshape->width, (pshape->top_width + tr_left_sum + (h - pshape->height + 1) - 1) / (h - pshape->height + 1));
                                    _low_bound = _low_bound * h;
                                    // std::cout << "_low_bound: " << _low_bound << " h: " << h << std::endl;
                                    if (_low_bound < low_bound) {
                                        low_bound = _low_bound;
                                    }
                                }
                                // std::cout << "low_bound: " << low_bound << " tr_left_sum: " << tr_left_sum << std::endl;
                                // << min_potential_macro_area << std::endl; std::cout << "min_cell_area: " << min_cell_area << std::endl; std::cout
                                // << pshape->height << "/ " << max_allowable_cell_height << std::endl; std::cout << low_bound << " " <<
                                // min_cell_area + 1 << std::endl;
                                if (low_bound > target_area) {
                                    delete pshape;
                                    pshape = nullptr;
                                    break;
                                }
                                if (pshape->height > max_allowable_cell_height) {
                                    delete pshape;
                                    pshape = nullptr;
                                    break;
                                }
                                if (low_bound < min_potential_macro_area) {
                                    for (auto item : new_partial_placement) {
                                        delete item;
                                        item = nullptr;
                                    }
                                    new_partial_placement.clear();
                                    new_partial_placement.shrink_to_fit();
                                    min_potential_macro_area = low_bound;
                                    new_partial_placement.push_back(pshape);
                                } else if (low_bound == min_potential_macro_area) {
                                    new_partial_placement.push_back(pshape);
                                } else {
                                    delete pshape;
                                    pshape = nullptr;
                                }
                                break;
                            }
                            col++;
                        }
                    }
                }
            }
            n->partial_shapes = new_partial_placement;
            // remained_pmos.erase(std::remove(remained_pmos.begin(), remained_pmos.end(), current_tr), remained_pmos.end());
            for (auto it = remained_pmos.begin(); it != remained_pmos.end();) {
                if (*it == current_tr) {
                    it = remained_pmos.erase(it);  // 刪除元素並返回新的位置
                } else {
                    ++it;
                }
            }

            n->remained_pmos = remained_pmos;
            n->tr_left_sum = tr_left_sum;
            n->parent = current_node;
            n->tr = current_tr;
            n->fill = 0;
            current_node->children.push_back(n);
            current_node = n;
        }
    }
    // auto end_dfs = std::chrono::high_resolution_clock::now();
    // std::chrono::duration<double> elapsed_dfs = end_dfs - start_dfs;
    // std::cout << "DFS Time taken : " << elapsed_dfs.count() << " seconds" << std::endl;
    // std::cout << "placement_cand.size(): " << placement_cand.size() << std::endl;
    return placement_cand;
}

void placement() {
    std::vector<Transistor *> pmos_group1;
    std::vector<std::vector<int>> common_signal_vec(pmos.size(), std::vector<int>(pmos.size(), 0));
    for (int i = 0; i < pmos.size(); i++) {
        for (int j = 0; j < pmos.size(); j++) {
            std::vector<Signal *> sig_vec1;
            std::vector<Signal *> sig_vec2;
            sig_vec1.push_back(pmos[i]->drain);
            sig_vec1.push_back(pmos[i]->gate);
            sig_vec1.push_back(pmos[i]->source);
            sig_vec1.push_back(tr_pairs[pmos[i]]->drain);
            sig_vec1.push_back(tr_pairs[pmos[i]]->gate);
            sig_vec1.push_back(tr_pairs[pmos[i]]->source);
            sig_vec2.push_back(pmos[j]->drain);
            sig_vec2.push_back(pmos[j]->gate);
            sig_vec2.push_back(pmos[j]->source);
            sig_vec2.push_back(tr_pairs[pmos[j]]->drain);
            sig_vec2.push_back(tr_pairs[pmos[j]]->gate);
            sig_vec2.push_back(tr_pairs[pmos[j]]->source);
            std::set<Signal *> sig_set1(sig_vec1.begin(), sig_vec1.end());
            std::set<Signal *> sig_set2(sig_vec2.begin(), sig_vec2.end());
            std::vector<Signal *> intersection;
            std::set_intersection(sig_set1.begin(), sig_set1.end(), sig_set2.begin(), sig_set2.end(), std::back_inserter(intersection));
            common_signal_vec[i][j] = intersection.size();
        }
    }
    for (int i = 0; i < pmos.size(); i++) {
        for (int j = 0; j < pmos.size(); j++) {
            std::cout << common_signal_vec[i][j];
        }
        std::cout << std::endl;
    }
    pmos_group1 = pmos;
    group_placement(pmos_group1);
}

void group_placement(std::vector<Transistor *> pmos_group) {
    std::vector<double> workload;
    double bfs_total_time = 0;
    double dfs_total_time = 0;
    workload.assign(16, 0);
    tr_size_sum = 0;
    int min_cell_area = std::numeric_limits<int>::max() - 1;
    int min_macro_area = std::numeric_limits<int>::max() - 1;

    for (Transistor *tr : pmos) {
        tr_size_sum = tr_size_sum + std::max(tr->num_finger, tr_pairs[tr]->num_finger);
    }

    int target_area = tr_size_sum;

    // assign shape to each transistor
    for (Transistor *tr : pmos) {
        std::vector<Lambda *> multi_row_config;
        for (auto _p_shape : phi_merged[tr]) {
            for (auto lamb : _p_shape.second) {
                multi_row_config.push_back(lamb);
            }
        }
        multi_row_configs.insert(std::make_pair(tr, multi_row_config));
    }

    while (final_placement_cand.size() == 0) {
        double max_dfs_time_taken = 0;
        auto start_while = std::chrono::high_resolution_clock::now();
        auto start_bfs = std::chrono::high_resolution_clock::now();
        auto item = bfs_placement(target_area);
        auto end_bfs = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed_bfs = end_bfs - start_bfs;
        std::cout << "BFS Time taken : " << elapsed_bfs.count() << std::endl;
        bfs_total_time += elapsed_bfs.count();
        if (item.second.size() != 0) {
            final_placement_cand = item.second;
            break;
        } else {
            auto node_to_be_processed = item.first;
            auto start_dfs_total = std::chrono::high_resolution_clock::now();
#pragma omp parallel for schedule(dynamic)
            for (auto n : node_to_be_processed) {
                if (final_placement_cand.size() >= max_placement_size) continue;
                auto start_dfs = std::chrono::high_resolution_clock::now();
                int pshape_size = n->partial_shapes.size();
                auto new_placement_cand = dfs_placement(n, target_area);
                auto end_dfs = std::chrono::high_resolution_clock::now();
                std::chrono::duration<double> elapsed_dfs = end_dfs - start_dfs;
                std::cout << "DFS Time taken : " << elapsed_dfs.count() << " seconds #pshape: " << pshape_size << std::endl;
                max_dfs_time_taken = std::max(max_dfs_time_taken, elapsed_dfs.count());
                for (auto pshape : new_placement_cand) {
                    final_placement_cand.push_back(pshape);
                }
                int thread_id = omp_get_thread_num();
                workload[thread_id] += elapsed_dfs.count();
            }
            auto end_dfs_total = std::chrono::high_resolution_clock::now();
            std::chrono::duration<double> elapsed_dfs_total = end_dfs_total - start_dfs_total;
            dfs_total_time += elapsed_dfs_total.count();
            std::cout << "max_dfs_time_taken: " << max_dfs_time_taken << std::endl;
            for (int i = 0; i < 16; i++) {
                std::cout << workload[i] << ", ";
            }
            std::cout << std::endl;
        }
        workload.assign(16, 0);
        target_area++;
        auto end_while = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed_while = end_while - start_while;
        std::cout << "Time taken : " << elapsed_while.count() << " seconds" << std::endl;
    }

    std::cout << "bfs total time: " << bfs_total_time << std::endl;
    std::cout << "dfs total time: " << dfs_total_time << std::endl;

    std::cout << "number of cell: " << final_placement_cand.size() << std::endl;
    int place_cand_id = 0;

    for (auto pshape : final_placement_cand) {
        std::cout << "min_macro_area: " << pshape->multirow_macro_area << std::endl;
        std::cout << "#" << place_cand_id << std::endl;
        // print transistor name
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                if (pshape->multirow_tr_permutation_up[i][j] == nullptr) {
                    std::cout << "     ";
                } else {
                    std::cout << std::left << std::setw(4) << pshape->multirow_tr_permutation_up[i][j]->name << " ";
                }
            }
            std::cout << std::endl;
        }
        std::cout << "--" << std::endl;
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                if (pshape->multirow_tr_permutation_down[i][j] == nullptr) {
                    std::cout << "     ";
                } else {
                    std::cout << std::left << std::setw(4) << pshape->multirow_tr_permutation_down[i][j]->name << " ";
                }
            }
            std::cout << std::endl;
        }
        // print active
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                Transistor *tr_n = pshape->multirow_tr_permutation_up[i][j];
                switch (pshape->multirow_tr_shape_up[i][j]) {
                    case 0:
                        std::cout << std::left << std::setw(7) << tr_n->drain->name << " " << std::left << std::setw(7) << tr_n->gate->name << " " << std::left
                                  << std::setw(7) << tr_n->source->name << " ";
                        break;
                    case 1:
                        std::cout << std::left << std::setw(7) << tr_n->source->name << " " << std::left << std::setw(7) << tr_n->gate->name << " " << std::left
                                  << std::setw(7) << tr_n->drain->name << " ";
                        break;
                    case 2:
                        std::cout << "------------------------";
                        break;
                }
            }
            std::cout << std::endl;
        }
        std::cout << "--" << std::endl;
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                Transistor *tr_p = pshape->multirow_tr_permutation_down[i][j];
                switch (pshape->multirow_tr_shape_down[i][j]) {
                    case 0:
                        std::cout << std::left << std::setw(7) << tr_p->drain->name << " " << std::left << std::setw(7) << tr_p->gate->name << " " << std::left
                                  << std::setw(7) << tr_p->source->name << " ";
                        break;
                    case 1:
                        std::cout << std::left << std::setw(7) << tr_p->source->name << " " << std::left << std::setw(7) << tr_p->gate->name << " " << std::left
                                  << std::setw(7) << tr_p->drain->name << " ";
                        break;
                    case 2:
                        std::cout << "------------------------";
                        break;
                }
            }
            std::cout << std::endl;
        }
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                std::cout << pshape->multirow_tr_shape_up[i][j];
            }
            std::cout << std::endl;
        }
        std::cout << "--" << std::endl;
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                std::cout << pshape->multirow_tr_shape_down[i][j];
            }
            std::cout << std::endl;
        }
        std::cout << std::endl;
        place_cand_id++;
    }
    // 指定資料夾名稱
    std::string folderName = "results";

    if (fs::exists(folderName)) {
        // 刪除資料夾及其內容
        fs::remove_all(folderName);
        std::cout << "資料夾 " << folderName << " 已刪除。" << std::endl;
    } else {
        std::cout << "資料夾 " << folderName << " 不存在。" << std::endl;
    }

    // 創建資料夾
    if (createFolder(folderName) == 0) {
        std::cout << "資料夾 " << folderName << " 已成功創建！" << std::endl;
    } else {
        std::cerr << "無法創建資料夾 " << folderName << "，可能已存在。" << std::endl;
    }

    // 將輸出寫入該資料夾中的不同檔案
    for (int i = 0; i < final_placement_cand.size(); i++) {
        Pshape *pshape = final_placement_cand[i];
        // 構造檔案路徑
        std::string fileName = folderName + "/output_" + std::to_string(i) + ".plmt";

        // 打開文件輸出流
        std::ofstream outputFile(fileName);
        if (!outputFile) {
            std::cerr << "無法創建檔案 " << fileName << std::endl;
            continue;
        }

        // 寫入內容
        // outputFile << "<NAME> " << i << std::endl;
        // outputFile << "<OUTPUT> Y" << std::endl;
        // outputFile << "<POWER> VDD" << std::endl;
        // outputFile << "<GROUND> VSS" << std::endl;
        // outputFile << "<INPUT> A B" << std::endl;
        // outputFile << "<NAME> " << i << std::endl;
        // outputFile << "<OUTPUT> QN" << std::endl;
        // outputFile << "<POWER> VDD" << std::endl;
        // outputFile << "<GROUND> VSS" << std::endl;
        // outputFile << "<INPUT> CLK D" << std::endl;
        outputFile << "<NAME> " << i << std::endl;
        outputFile << "<OUTPUT> CON SN" << std::endl;
        outputFile << "<POWER> VDD" << std::endl;
        outputFile << "<GROUND> VSS" << std::endl;
        outputFile << "<INPUT> A B CI" << std::endl;
        outputFile << std::endl;
        outputFile << "<PMOS> " << pshape->width << " ( ";
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                Transistor *tr_p = pshape->multirow_tr_permutation_down[i][j];
                switch (pshape->multirow_tr_shape_down[i][j]) {
                    case 0:
                        outputFile << tr_p->width / tr_p->num_finger << " ";
                        break;
                    case 1:
                        outputFile << tr_p->width / tr_p->num_finger << " ";
                        break;
                    case 2:
                        outputFile << "81 ";
                        break;
                }
            }
            outputFile << ")" << std::endl;
        }
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                Transistor *tr_p = pshape->multirow_tr_permutation_down[i][j];
                switch (pshape->multirow_tr_shape_down[i][j]) {
                    case 0:
                        outputFile << tr_p->drain->name << " <" << tr_p->gate->name << "> " << tr_p->source->name << " ";
                        break;
                    case 1:
                        outputFile << tr_p->source->name << " <" << tr_p->gate->name << "> " << tr_p->drain->name << " ";
                        break;
                    case 2:
                        outputFile << "VDD <VDD> VDD ";
                        break;
                }
            }
            outputFile << std::endl;
        }
        outputFile << std::endl;
        outputFile << "<NMOS> " << pshape->width << " ( ";
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                Transistor *tr_n = pshape->multirow_tr_permutation_up[i][j];
                switch (pshape->multirow_tr_shape_up[i][j]) {
                    case 0:
                        outputFile << tr_n->width / tr_n->num_finger << " ";
                        break;
                    case 1:
                        outputFile << tr_n->width / tr_n->num_finger << " ";
                        break;
                    case 2:
                        outputFile << "81";
                        break;
                }
            }
            outputFile << ")" << std::endl;
        }
        for (int i = 0; i < pshape->height; i++) {
            for (int j = 0; j < pshape->width; j++) {
                Transistor *tr_n = pshape->multirow_tr_permutation_up[i][j];
                switch (pshape->multirow_tr_shape_up[i][j]) {
                    case 0:
                        outputFile << tr_n->drain->name << " <" << tr_n->gate->name << "> " << tr_n->source->name << " ";
                        break;
                    case 1:
                        outputFile << tr_n->source->name << " <" << tr_n->gate->name << "> " << tr_n->drain->name << " ";
                        break;
                    case 2:
                        outputFile << "VSS <VSS> VSS ";
                        break;
                }
            }
            outputFile << std::endl;
        }
        outputFile.close();

        std::cout << "內容已寫入檔案 " << fileName << std::endl;
    }
}
