#include "cfet.h"

#include <chrono>
#include <iostream>
#include <map>
#include <queue>
#include <sstream>
#include <unordered_map>
#include <vector>

Shape::Shape() {
    num_row = 0;
    num_finger = 0;
    id = 0;
}
Transistor::Transistor() {}

Signal::Signal() {}

Pshape::Pshape() { id_device = nullptr; }

Node::Node() { fill = 0; }

Lambda::Lambda() {}

std::string cell_name;
std::vector<std::string> io_pins;
std::vector<Transistor*> trs;
std::vector<Transistor*> pmos;
std::vector<Transistor*> nmos;
std::unordered_map<std::string, Transistor*> tr_dict;
std::unordered_map<std::string, Signal*> signals;
std::unordered_map<Transistor*, Transistor*> tr_pairs;
std::unordered_map<Transistor*, std::unordered_map<Shape*, std::vector<Lambda*>>> phi;
std::unordered_map<Transistor*, std::unordered_map<Shape*, std::vector<Lambda*>>> phi_merged;
std::unordered_map<std::string, Shape*> CFETShapes;
std::unordered_map<Transistor*, std::vector<Lambda*>> multi_row_configs;
std::vector<Pshape*> final_placement_cand;
int tr_size_sum = 0;
std::unordered_map<int, Lambda*> lambda_dict;
int* ds_dict;
int lamb_id = 0;

int max_cfet_width = 81.0;
int diffusion_break_constraint = 1;
int max_placement_size = 1;
int max_allowable_cell_height = 2;
int num_nodes_parsed_to_gpu = 10000;
float relaxation_parameter = 0;