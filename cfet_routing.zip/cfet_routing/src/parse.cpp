#include <chrono>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <queue>
#include <regex>
#include <sstream>
#include <unordered_map>
#include <vector>

#include "routing.h"
#include "z3++.h"

void parse_input(std::vector<std::ifstream*> streams) {
    z3::solver solver(ctx);
    std::string token;
    std::string line;
    int rows, cols;
    int height = 3;
    std::vector<SingleRow*> single_rows;
    std::vector<std::vector<std::vector<bool>>> via_matrix_bool;
    std::vector<std::vector<std::vector<bool>>> metal_matrix_bool;
    int max_cols = 0;
    Layout* layout = new Layout();

    std::vector<int> row_bias;
    std::vector<int> row_length;
    row_bias.resize(streams.size());
    row_length.resize(streams.size());

    for (int f = 0; f < streams.size(); f++) {
        std::ifstream* stream = streams[f];
        std::getline(*stream, line);

        std::istringstream iss(line);

        iss >> rows >> cols;
        row_length[f] = cols;
        if (cols > max_cols) {
            max_cols = cols;
        }
    }

    // assign row_bias
    for (int f = 0; f < streams.size(); f++) {
        row_bias[f] = (max_cols - row_length[f]) / 2;
        std::cout << f << ": " << row_bias[f] << std::endl;
    }

    metal_matrix_bool.resize(height);
    for (int i = 0; i < height; ++i) {
        metal_matrix_bool[i].assign(rows * streams.size(), std::vector<bool>(max_cols, false));
    }
    for (int i = 0; i < metal_matrix_bool.size(); i++) {
        for (int j = 0; j < metal_matrix_bool[i].size(); j++) {
            for (int k = 0; k < metal_matrix_bool[i][j].size(); k++) {
                metal_matrix_bool[i][j][k] = false;
            }
        }
    }
    via_matrix_bool.resize(height);
    for (int i = 0; i < height; ++i) {
        via_matrix_bool[i].assign(rows * streams.size(), std::vector<bool>(max_cols, false));
    }
    for (int i = 0; i < via_matrix_bool.size(); i++) {
        for (int j = 0; j < via_matrix_bool[i].size(); j++) {
            for (int k = 0; k < via_matrix_bool[i][j].size(); k++) {
                via_matrix_bool[i][j][k] = false;
            }
        }
    }

    // metal_matrix.resize(height);
    // for (int i = 0; i < height; ++i) {
    //     metal_matrix[i].assign(rows * streams.size(), std::vector<z3::expr>(max_cols, ctx.bool_val(false)));
    // }
    // via_matrix.resize(height);
    // for (int i = 0; i < height; ++i) {
    //     via_matrix[i].assign(rows * streams.size(), std::vector<z3::expr>(max_cols, ctx.bool_val(false)));
    // }

    // 使用 z3::expr 為 matrix 賦值
    // for (int i = 0; i < height; ++i) {
    //     for (int j = 0; j < rows * streams.size(); ++j) {
    //         for (int k = 0; k < max_cols; ++k) {
    //             // 這裡使用 z3::expr 為每個元素賦一個表達式
    //             metal_matrix[i][j][k] = ctx.bool_const(("metal_" + std::to_string(i) + "_" + std::to_string(j) + "_" + std::to_string(k)).c_str());
    //         }
    //     }
    // }
    // for (int i = 0; i < via_matrix.size(); ++i) {
    //     for (int j = 0; j < rows * streams.size(); ++j) {
    //         for (int k = 0; k < max_cols; ++k) {
    //             // 這裡使用 z3::expr 為每個元素賦一個表達式
    //             via_matrix[i][j][k] = ctx.bool_const(("via_" + std::to_string(i) + "_" + std::to_string(j) + "_" + std::to_string(k)).c_str());
    //         }
    //     }
    // }

    for (int f = 0; f < streams.size(); f++) {
        std::ifstream* stream = streams[f];
        std::getline(*stream, line);
        std::istringstream iss(line);
        SingleRow* single_row = new SingleRow();

        single_row->metal_matrix.resize(height);
        for (int i = 0; i < height; ++i) {
            single_row->metal_matrix[i].assign(rows, std::vector<bool>(max_cols, false));
        }
        single_row->via_matrix.resize(height);
        for (int i = 0; i < height; ++i) {
            single_row->via_matrix[i].assign(rows, std::vector<bool>(max_cols, false));
        }

        while (std::getline(*stream, line)) {
            std::istringstream iss(line);
            iss >> token;
            if (token == "<CA>") break;
        }
        while (std::getline(*stream, line)) {
            std::istringstream iss(line);
            int row;
            int col;
            iss >> token;
            iss >> row >> col;
            if (token == "<m0>") break;
            if (f % 2 == 0) {
                // solver.add(via_matrix[0][f * 4 + row][col]);
                via_matrix_bool[0][f * 4 + row][col] = true;
                single_row->via_matrix[0][row][col] = true;
            } else {
                // solver.add(via_matrix[0][f * 4 + 3 - row][col]);
                via_matrix_bool[0][f * 4 + 3 - row][col] = true;
                single_row->via_matrix[0][row][col] = true;
            }
        }
        while (std::getline(*stream, line)) {
            std::istringstream iss(line);
            int row;
            int col_begin;
            int length;
            iss >> token;
            if (token == "<v01>") break;
            iss >> row >> col_begin >> length;
            for (int i = col_begin; i < col_begin + length; i++) {
                if (f % 2 == 0) {
                    // solver.add(metal_matrix[0][f * 4 + row][i]);
                    metal_matrix_bool[0][f * 4 + row][i] = true;
                    single_row->metal_matrix[0][row][i] = true;
                } else {
                    // solver.add(metal_matrix[0][f * 4 + 3 - row][i]);
                    metal_matrix_bool[0][f * 4 + 3 - row][i] = true;
                    single_row->metal_matrix[0][row][i] = true;
                }
            }
        }
        while (std::getline(*stream, line)) {
            std::istringstream iss(line);
            int row;
            int col;
            iss >> token;
            iss >> row >> col;
            if (token == "<m1>") break;
            if (f % 2 == 0) {
                // solver.add(via_matrix[1][f * 4 + row][col]);
                via_matrix_bool[1][f * 4 + row][col] = true;
                single_row->via_matrix[1][row][col] = true;
            } else {
                // solver.add(via_matrix[1][f * 4 + 3 - row][col]);
                via_matrix_bool[1][f * 4 + 3 - row][col] = true;
                single_row->via_matrix[1][row][col] = true;
            }
        }
        while (std::getline(*stream, line)) {
            std::istringstream iss(line);
            int col;
            int row_begin;
            int length;
            iss >> token;
            if (token == "<v12>") break;
            iss >> col >> row_begin >> length;
            for (int i = row_begin; i < row_begin + length; i++) {
                if (f % 2 == 0) {
                    // solver.add(metal_matrix[1][f * 4 + i][col]);
                    metal_matrix_bool[1][f * 4 + i][col] = true;
                    single_row->metal_matrix[1][i][col] = true;
                } else {
                    // solver.add(metal_matrix[1][f * 4 + 3 - i][col]);
                    metal_matrix_bool[1][f * 4 + 3 - i][col] = true;
                    single_row->metal_matrix[1][i][col] = true;
                }
            }
        }
        while (std::getline(*stream, line)) {
            std::istringstream iss(line);
            int row;
            int col;
            iss >> token;
            iss >> row >> col;
            if (token == "<m2>") break;
            if (f % 2 == 0) {
                // solver.add(via_matrix[2][f * 4 + row][col]);
                via_matrix_bool[2][f * 4 + row][col] = true;
                single_row->via_matrix[2][row][col] = true;
            } else {
                // solver.add(via_matrix[2][f * 4 + 3 - row][col]);
                via_matrix_bool[2][f * 4 + 3 - row][col] = true;
                single_row->via_matrix[2][row][col] = true;
            }
        }
        while (std::getline(*stream, line)) {
            std::istringstream iss(line);
            iss >> token;
            int row;
            int col_begin;
            int length;
            iss >> token;
            if (token == "<Placement>") break;
            iss >> row >> col_begin >> length;
            for (int i = col_begin; i < col_begin + length; i++) {
                if (f % 2 == 0) {
                    // solver.add(metal_matrix[2][f * 4 + row][i]);
                    metal_matrix_bool[2][f * 4 + row][i] = true;
                    single_row->metal_matrix[2][row][i] = true;
                } else {
                    // solver.add(metal_matrix[2][f * 4 + 3 - row][i]);
                    metal_matrix_bool[2][f * 4 + 3 - row][i] = true;
                    single_row->metal_matrix[2][row][i] = true;
                }
            }
        }
        layout->single_rows.push_back(single_row);
    }

    std::vector<int> order = {0, 1, 2, 3};
    std::vector<bool> flip = {false, false, false, false};
    layout->order = order;
    layout->flip = flip;

    std::cout << "Initial information" << std::endl;
    // z3::model m = solver.get_model();
    std::cout << "metal: " << std::endl;
    for (int i = 0; i < metal_matrix_bool.size(); i++) {
        std::cout << "z = " << i << std::endl;
        for (int j = 0; j < metal_matrix_bool[i].size(); j++) {
            for (int k = 0; k < metal_matrix_bool[i][j].size(); k++) {
                // std::cout << (m.eval(metal_matrix[i][j][k]).bool_value() == Z3_L_TRUE ? "1" : "0");
                std::cout << metal_matrix_bool[i][j][k];
            }
            std::cout << std::endl;
        }
    }

    std::cout << "via: " << std::endl;
    for (int i = 0; i < via_matrix_bool.size(); i++) {
        std::cout << "z = " << i << std::endl;
        for (int j = 0; j < via_matrix_bool[i].size(); j++) {
            for (int k = 0; k < via_matrix_bool[i][j].size(); k++) {
                // std::cout << (m.eval(via_matrix[i][j][k]).bool_value() == Z3_L_TRUE ? "1" : "0");
                std::cout << via_matrix_bool[i][j][k];
            }
            std::cout << std::endl;
        }
    }

    while (true) {
        std::cout << "order: ";
        for (int i = 0; i < order.size(); i++) {
            std::cout << order[i] << " ";
        }
        std::cout << std::endl;

        metal_matrix_bool.resize(height);
        for (int i = 0; i < height; ++i) {
            metal_matrix_bool[i].assign(rows * streams.size(), std::vector<bool>(max_cols, false));
        }
        via_matrix_bool.resize(height);
        for (int i = 0; i < height; ++i) {
            via_matrix_bool[i].assign(rows * streams.size(), std::vector<bool>(max_cols, false));
        }
        layout->metal_matrix.resize(height);
        for (int i = 0; i < height; ++i) {
            layout->metal_matrix[i].assign(rows * streams.size(), std::vector<bool>(max_cols, false));
        }
        for (int i = 0; i < layout->metal_matrix.size(); i++) {
            for (int j = 0; j < layout->metal_matrix[i].size(); j++) {
                for (int k = 0; k < layout->metal_matrix[i][j].size(); k++) {
                    layout->metal_matrix[i][j][k] = false;
                }
            }
        }
        layout->via_matrix.resize(height);
        for (int i = 0; i < height; ++i) {
            layout->via_matrix[i].assign(rows * streams.size(), std::vector<bool>(max_cols, false));
        }
        for (int i = 0; i < layout->via_matrix.size(); i++) {
            for (int j = 0; j < layout->via_matrix[i].size(); j++) {
                for (int k = 0; k < layout->via_matrix[i][j].size(); k++) {
                    layout->via_matrix[i][j][k] = false;
                }
            }
        }
        layout->metal_segment_h.resize(height);
        for (int i = 0; i < layout->metal_segment_h.size(); ++i) {
            layout->metal_segment_h[i].assign(rows * streams.size(), std::vector<bool>(max_cols - 1, false));
        }
        layout->metal_segment_v.resize(height);
        for (int i = 0; i < layout->metal_segment_v.size(); ++i) {
            layout->metal_segment_v[i].assign(rows * streams.size() - 1, std::vector<bool>(max_cols, false));
        }
        layout->gL.resize(height);
        for (int i = 0; i < height; ++i) {
            layout->gL[i].assign(rows * streams.size(), std::vector<bool>(max_cols, false));
        }
        layout->gR.resize(height);
        for (int i = 0; i < height; ++i) {
            layout->gR[i].assign(rows * streams.size(), std::vector<bool>(max_cols, false));
        }
        layout->gF.resize(height);
        for (int i = 0; i < height; ++i) {
            layout->gF[i].assign(rows * streams.size(), std::vector<bool>(max_cols, false));
        }
        layout->gB.resize(height);
        for (int i = 0; i < height; ++i) {
            layout->gB[i].assign(rows * streams.size(), std::vector<bool>(max_cols, false));
        }

        // assign metal and via
        for (int s = 0; s < layout->order.size(); s++) {
            SingleRow* single_row = layout->single_rows[s];
            for (int i = 0; i < single_row->metal_matrix.size(); i++) {
                for (int j = 0; j < single_row->metal_matrix[i].size(); j++) {
                    for (int k = 0; k < single_row->metal_matrix[i][j].size(); k++) {
                        if (order[s] % 2 == 0) {
                            layout->metal_matrix[i][4 * order[s] + j][k] = single_row->metal_matrix[i][j][k];
                            layout->via_matrix[i][4 * order[s] + j][k] = single_row->via_matrix[i][j][k];
                            metal_matrix_bool[i][4 * order[s] + j][k] = single_row->metal_matrix[i][j][k];
                            via_matrix_bool[i][4 * order[s] + j][k] = single_row->via_matrix[i][j][k];
                        } else {
                            layout->metal_matrix[i][4 * order[s] + 3 - j][k] = single_row->metal_matrix[i][j][k];
                            layout->via_matrix[i][4 * order[s] + 3 - j][k] = single_row->via_matrix[i][j][k];
                            metal_matrix_bool[i][4 * order[s] + 3 - j][k] = single_row->metal_matrix[i][j][k];
                            via_matrix_bool[i][4 * order[s] + 3 - j][k] = single_row->via_matrix[i][j][k];
                        }
                    }
                }
            }
        }

        // assign metal segament
        for (int i = 0; i < layout->metal_segment_h.size(); i = i + 2) {
            for (int j = 0; j < layout->metal_segment_h[i].size(); j++) {
                for (int k = 0; k < layout->metal_segment_h[i][j].size(); k++) {
                    layout->metal_segment_h[i][j][k] = layout->metal_matrix[i][j][k] && layout->metal_matrix[i][j][k + 1];
                }
            }
        }
        for (int i = 1; i < layout->metal_segment_v.size(); i = i + 2) {
            for (int j = 0; j < layout->metal_segment_v[i].size(); j++) {
                for (int k = 0; k < layout->metal_segment_v[i][j].size(); k++) {
                    layout->metal_segment_v[i][j][k] = layout->metal_matrix[i][j][k] && layout->metal_matrix[i][j + 1][k];
                }
            }
        }

        // assign geometric variable
        for (int i = 0; i < height; i = i + 2) {
            for (int j = 0; j < layout->metal_segment_h[i].size(); ++j) {
                for (int k = 0; k < layout->metal_segment_h[i][j].size(); ++k) {
                    if (k == 0) {
                        layout->gL[i][j][k] = layout->metal_segment_h[i][j][k];
                    } else {
                        layout->gL[i][j][k] = !layout->metal_segment_h[i][j][k - 1] && layout->metal_segment_h[i][j][k];
                    }
                }
            }
        }
        for (int i = 0; i < height; i = i + 2) {
            for (int j = 0; j < layout->metal_segment_h[i].size(); ++j) {
                for (int k = 0; k < layout->metal_segment_h[i][j].size(); ++k) {
                    if (k == 0) {
                        layout->gR[i][j][k] = false;
                    } else {
                        layout->gR[i][j][k] = layout->metal_segment_h[i][j][k - 1] && !layout->metal_segment_h[i][j][k];
                    }
                }
            }
        }
        for (int i = 1; i < height; i = i + 2) {
            for (int j = 0; j < layout->metal_segment_v[i].size(); ++j) {
                for (int k = 0; k < layout->metal_segment_v[i][j].size(); ++k) {
                    if (j == 0) {
                        layout->gF[i][j][k] = layout->metal_segment_v[i][j][k];
                    } else {
                        layout->gF[i][j][k] = !layout->metal_segment_h[i][j - 1][k] && layout->metal_segment_h[i][j][k];
                    }
                }
            }
        }

        std::vector<int> bias(4, 0);
        bool found = false;
        generateBias(row_bias, bias, layout, 0, found);

        break;

        if (!std::next_permutation(order.begin(), order.end())) break;
    }
    std::cout << "order: ";
    for (int i = 0; i < layout->order.size(); i++) {
        std::cout << layout->order[i] << " ";
    }
    std::cout << std::endl;
    std::cout << "bias: ";
    for (int i = 0; i < layout->bias.size(); i++) {
        std::cout << layout->bias[i] << " ";
    }
    std::cout << std::endl;
    std::cout << "flip: ";
    for (int i = 0; i < layout->flip.size(); i++) {
        std::cout << layout->flip[i] << " ";
    }
    std::cout << std::endl;

    std::cout << "metal: " << std::endl;
    for (int i = 0; i < layout->metal_matrix.size(); i++) {
        std::cout << "z = " << i << std::endl;
        for (int j = 0; j < layout->metal_matrix[i].size(); j++) {
            for (int k = 0; k < layout->metal_matrix[i][j].size(); k++) {
                std::cout << layout->metal_matrix[i][j][k];
            }
            std::cout << std::endl;
        }
    }

    std::cout << "via: " << std::endl;
    for (int i = 0; i < layout->via_matrix.size(); i++) {
        std::cout << "z = " << i << std::endl;
        for (int j = 0; j < layout->via_matrix[i].size(); j++) {
            for (int k = 0; k < layout->via_matrix[i][j].size(); k++) {
                std::cout << layout->via_matrix[i][j][k];
            }
            std::cout << std::endl;
        }
    }
}