#include "routing.h"

#include <cuda_runtime.h>
#include <omp.h>
#include <sys/stat.h>  // Linux/Unix 系統用於創建資料夾

#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <mutex>
#include <queue>
#include <set>
#include <sstream>
#include <unordered_map>
#include <utility>
#include <vector>

#include "z3++.h"

z3::context ctx;
std::vector<std::vector<std::vector<z3::expr>>> metal_matrix;
std::vector<std::vector<std::vector<z3::expr>>> via_matrix;

Layout::Layout() {}
SingleRow::SingleRow() {}