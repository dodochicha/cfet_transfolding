#ifndef CFET_H_
#define CFET_H_

#include <cuda_runtime.h>

#include <chrono>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <unordered_map>
#include <utility>
#include <vector>

#include "z3++.h"

class Layout;
class SingleRow;

extern z3::context ctx;
extern std::vector<std::vector<std::vector<z3::expr>>> metal_matrix;
extern std::vector<std::vector<std::vector<z3::expr>>> via_matrix;

void parse_input(std::vector<std::ifstream*> streams);
void generateBias(const std::vector<int>& row_bias, std::vector<int>& bias, Layout* layout, size_t index, bool& found);
void formulate_layout(Layout* layout);
bool fix_by_flipping(Layout* layout);
bool via_rule_violation(Layout* layout);
bool metal_rule_violation(Layout* layout);
bool prl_rule_violation(std::vector<int> bias);

class Layout {
   public:
    Layout();
    std::vector<SingleRow*> single_rows;
    std::vector<int> order;
    std::vector<int> bias;
    std::vector<bool> flip;
    std::vector<std::vector<std::vector<bool>>> metal_matrix;
    std::vector<std::vector<std::vector<bool>>> via_matrix;
    std::vector<std::vector<std::vector<bool>>> metal_segment_h;
    std::vector<std::vector<std::vector<bool>>> metal_segment_v;
    std::vector<std::vector<std::vector<bool>>> gL;
    std::vector<std::vector<std::vector<bool>>> gR;
    std::vector<std::vector<std::vector<bool>>> gF;
    std::vector<std::vector<std::vector<bool>>> gB;
};

class SingleRow {
   public:
    SingleRow();

    std::vector<std::vector<std::vector<bool>>> metal_matrix;
    std::vector<std::vector<std::vector<bool>>> via_matrix;
};

#endif