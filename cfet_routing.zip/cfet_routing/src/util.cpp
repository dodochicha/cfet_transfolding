#include <cuda_runtime.h>
#include <omp.h>
#include <sys/stat.h>  // Linux/Unix 系統用於創建資料夾

#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <future>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <mutex>
#include <queue>
#include <set>
#include <sstream>
#include <unordered_map>
#include <utility>
#include <vector>

#include "routing.h"
#include "z3++.h"

bool via_rule_violation(Layout* layout) {
    z3::context c;
    z3::solver solver(c);
    std::vector<std::vector<std::vector<z3::expr>>> via_matrix_copy;
    auto via_matrix_bool = layout->via_matrix;

    via_matrix_copy.resize(via_matrix_bool.size());
    for (int i = 0; i < via_matrix_bool.size(); ++i) {
        via_matrix_copy[i].assign(via_matrix_bool[0].size(), std::vector<z3::expr>(via_matrix_bool[0][0].size(), ctx.bool_val(false)));
    }
    for (int i = 0; i < via_matrix_copy.size(); i++) {
        for (int j = 0; j < via_matrix_copy[i].size(); j++) {
            for (int k = 0; k < via_matrix_copy[i][j].size(); k++) {
                via_matrix_copy[i][j][k] = (layout->via_matrix[i][j][k] == true) ? c.bool_val(true) : c.bool_val(false);
            }
        }
    }
    for (int i = 0; i < via_matrix_copy.size(); i++) {
        for (int j = 0; j < via_matrix_copy[i].size(); j++) {
            for (int k = 0; k < via_matrix_copy[i][j].size(); k++) {
                if (j > 0)  // 上方相鄰
                    solver.add(!(via_matrix_copy[i][j][k] && via_matrix_copy[i][j - 1][k]));
                if (j < via_matrix_copy[i].size() - 1)  // 下方相鄰
                    solver.add(!(via_matrix_copy[i][j][k] && via_matrix_copy[i][j + 1][k]));
                if (k > 0)  // 左方相鄰
                    solver.add(!(via_matrix_copy[i][j][k] && via_matrix_copy[i][j][k - 1]));
                if (k < via_matrix_copy[i][j].size() - 1)  // 右方相鄰
                    solver.add(!(via_matrix_copy[i][j][k] && via_matrix_copy[i][j][k + 1]));
            }
        }
    }
    if (solver.check() == z3::sat) {
        std::cout << "via rule SAT" << std::endl;
        z3::model m = solver.get_model();
        return false;
    } else {
        std::cout << "via rule UNSAT" << std::endl;
        return true;
    }
}

bool metal_rule_violation(Layout* layout) {
    z3::context c;
    z3::solver solver(c);
    std::vector<std::vector<std::vector<z3::expr>>> gL_copy;
    std::vector<std::vector<std::vector<z3::expr>>> gR_copy;
    std::vector<std::vector<std::vector<bool>>> metal_matrix_copy;
    auto gL = layout->gL;
    auto gR = layout->gR;
    auto metal_matrix = layout->metal_matrix;
    gL_copy.resize(gL.size());
    for (int i = 0; i < gL_copy.size(); ++i) {
        gL_copy[i].assign(gL[i].size(), std::vector<z3::expr>(gL[0][0].size(), ctx.bool_val(false)));
    }
    gR_copy.resize(gR.size());
    for (int i = 0; i < gR_copy.size(); ++i) {
        gR_copy[i].assign(gR[i].size(), std::vector<z3::expr>(gR[0][0].size(), ctx.bool_val(false)));
    }
    metal_matrix_copy.resize(metal_matrix.size());
    for (int i = 0; i < gR_copy.size(); ++i) {
        metal_matrix_copy[i].assign(metal_matrix[i].size(), std::vector<bool>(metal_matrix[0][0].size(), false));
    }
    for (int i = 0; i < gL.size(); i++) {
        for (int j = 0; j < gL[i].size(); j++) {
            for (int k = 0; k < gL[i][j].size(); k++) {
                gL_copy[i][j][k] = (gL[i][j][k] == true) ? c.bool_val(true) : c.bool_val(false);
            }
        }
    }
    for (int i = 0; i < gR.size(); i++) {
        for (int j = 0; j < gR[i].size(); j++) {
            for (int k = 0; k < gR[i][j].size(); k++) {
                gR_copy[i][j][k] = (layout->gR[i][j][k]) ? c.bool_val(true) : c.bool_val(false);
            }
        }
    }
    for (int i = 0; i < metal_matrix.size(); i++) {
        for (int j = 0; j < metal_matrix[i].size(); j++) {
            for (int k = 0; k < metal_matrix[i][j].size(); k++) {
                metal_matrix_copy[i][j][k] = (layout->metal_matrix[i][j][k] == true) ? true : false;
            }
        }
    }
    // PRL design rule
    for (int i = 0; i < gL.size(); i++) {
        for (int j = 0; j < gL[i].size(); j++) {
            for (int k = 0; k < gL[i][j].size(); k++) {
                if (j != gL[i].size() - 1) {
                    solver.add(!(gL_copy[i][j][k] && gR_copy[i][j + 1][k]));
                    solver.add(!(gR_copy[i][j][k] && gL_copy[i][j + 1][k]));
                }
            }
        }
    }
    // SHR design rule
    for (int i = 0; i < gL.size(); i++) {
        for (int j = 0; j < gL[i].size(); j++) {
            for (int k = 0; k < gL[i][j].size(); k++) {
                if (k < gL[i][j].size() - 1) {
                    if (j < gL[i].size() - 1) {
                        solver.add(!(gR_copy[i][j][k] && gR_copy[i][j + 1][k + 1]));
                    }
                    if (j > 0) {
                        solver.add(!(gR_copy[i][j][k] && gR_copy[i][j - 1][k + 1]));
                    }
                }
                if (k > 0) {
                    if (j < gL[i].size() - 1) {
                        solver.add(!(gL_copy[i][j][k] && gL_copy[i][j + 1][k - 1]));
                    }
                    if (j > 0) {
                        solver.add(!(gL_copy[i][j][k] && gL_copy[i][j - 1][k - 1]));
                    }
                }
            }
        }
    }
    if (solver.check() == z3::sat) {
        std::cout << "METAL rule SAT" << std::endl;
        z3::model m = solver.get_model();
        return false;
    } else {
        std::cout << "METAL rule UNSAT" << std::endl;
        return true;
    }
}

void generateBias(const std::vector<int>& row_bias, std::vector<int>& bias, Layout* layout, size_t index, bool& found) {
    if (found) return;  // 若已找到符合條件的組合，立即停止遞迴

    if (index == row_bias.size()) {
        layout->bias = bias;
        formulate_layout(layout);
        if (via_rule_violation(layout) == false) {
            if (metal_rule_violation(layout) == false) {
                std::cout << "Found: {";
                for (size_t i = 0; i < bias.size(); ++i) {
                    std::cout << bias[i] << (i < bias.size() - 1 ? ", " : "");
                }
                std::cout << "}" << std::endl;
                found = true;  // 設置 flag 以停止遞迴
            } else {
                bool fix_success = fix_by_flipping(layout);
                if (fix_success) {
                    found = true;
                }
            }
        } else {
            // bool fix_success = fix_by_flipping(layout);
            // std::cout << "fix_success: " << fix_success << std::endl;
        }
        return;
    }

    for (int val = 0; val <= row_bias[index]; ++val) {
        bias[index] = val;
        generateBias(row_bias, bias, layout, index + 1, found);
        if (found) return;  // 遞迴返回時再次確認是否找到
    }
}

bool fix_by_flipping(Layout* layout) {
    std::cout << "hello fix_by_flipping" << std::endl;
    int idx = 0;
    int height = 3;
    int max_cols = layout->metal_matrix[0][0].size();
    while (idx < layout->single_rows.size()) {
        for (int f = 0; f < layout->single_rows.size(); f++) {
            layout->flip[f] = (f == idx) ? true : false;
        }
        std::cout << "flip: ";
        for (int i = 0; i < layout->flip.size(); i++) {
            std::cout << layout->flip[i] << " ";
        }
        std::cout << std::endl;
        formulate_layout(layout);
        if (!via_rule_violation(layout)) {
            if (!metal_rule_violation(layout)) {
                std::cout << "success" << std::endl;
                return true;
            }
        }
        idx++;
    }
    for (int f = 0; f < layout->single_rows.size(); f++) {
        layout->flip[f] = false;
    }
    // assign metal and via
    for (int s = 0; s < layout->order.size(); s++) {
        SingleRow* single_row = layout->single_rows[s];
        for (int i = 0; i < single_row->metal_matrix.size(); i++) {
            for (int j = 0; j < single_row->metal_matrix[i].size(); j++) {
                for (int k = 0; k < single_row->metal_matrix[i][j].size(); k++) {
                    if (layout->flip[layout->order[s]] == false) {
                        if (layout->order[s] % 2 == 0) {
                            layout->metal_matrix[i][4 * layout->order[s] + j][k] = single_row->metal_matrix[i][j][k];
                            layout->via_matrix[i][4 * layout->order[s] + j][k] = single_row->via_matrix[i][j][k];
                        } else {
                            layout->metal_matrix[i][4 * layout->order[s] + 3 - j][k] = single_row->metal_matrix[i][j][k];
                            layout->via_matrix[i][4 * layout->order[s] + 3 - j][k] = single_row->via_matrix[i][j][k];
                        }
                    } else {
                        if (layout->order[s] % 2 == 0) {
                            layout->metal_matrix[i][4 * layout->order[s] + j][max_cols - k - 1] = single_row->metal_matrix[i][j][max_cols - k - 1];
                            layout->via_matrix[i][4 * layout->order[s] + j][max_cols - k - 1] = single_row->via_matrix[i][j][max_cols - k - 1];
                        } else {
                            layout->metal_matrix[i][4 * layout->order[s] + 3 - j][max_cols - k - 1] = single_row->metal_matrix[i][j][max_cols - k - 1];
                            layout->via_matrix[i][4 * layout->order[s] + 3 - j][max_cols - k - 1] = single_row->via_matrix[i][j][max_cols - k - 1];
                        }
                    }
                }
            }
        }
    }
    // assign metal segament
    for (int i = 0; i < layout->metal_segment_h.size(); i = i + 2) {
        for (int j = 0; j < layout->metal_segment_h[i].size(); j++) {
            for (int k = 0; k < layout->metal_segment_h[i][j].size(); k++) {
                layout->metal_segment_h[i][j][k] = layout->metal_matrix[i][j][k] && layout->metal_matrix[i][j][k + 1];
            }
        }
    }
    for (int i = 1; i < layout->metal_segment_v.size(); i = i + 2) {
        for (int j = 0; j < layout->metal_segment_v[i].size(); j++) {
            for (int k = 0; k < layout->metal_segment_v[i][j].size(); k++) {
                layout->metal_segment_v[i][j][k] = layout->metal_matrix[i][j][k] && layout->metal_matrix[i][j + 1][k];
            }
        }
    }

    // assign geometric variable
    for (int i = 0; i < height; i = i + 2) {
        for (int j = 0; j < layout->metal_segment_h[i].size(); ++j) {
            for (int k = 0; k < layout->metal_segment_h[i][j].size(); ++k) {
                if (k == 0) {
                    layout->gL[i][j][k] = layout->metal_segment_h[i][j][k];
                } else {
                    layout->gL[i][j][k] = !layout->metal_segment_h[i][j][k - 1] && layout->metal_segment_h[i][j][k];
                }
            }
        }
    }
    for (int i = 0; i < height; i = i + 2) {
        for (int j = 0; j < layout->metal_segment_h[i].size(); ++j) {
            for (int k = 0; k < layout->metal_segment_h[i][j].size(); ++k) {
                if (k == 0) {
                    layout->gR[i][j][k] = false;
                } else {
                    layout->gR[i][j][k] = layout->metal_segment_h[i][j][k - 1] && !layout->metal_segment_h[i][j][k];
                }
            }
        }
    }
    for (int i = 1; i < height; i = i + 2) {
        for (int j = 0; j < layout->metal_segment_v[i].size(); ++j) {
            for (int k = 0; k < layout->metal_segment_v[i][j].size(); ++k) {
                if (j == 0) {
                    layout->gF[i][j][k] = layout->metal_segment_v[i][j][k];
                } else {
                    layout->gF[i][j][k] = !layout->metal_segment_h[i][j - 1][k] && layout->metal_segment_h[i][j][k];
                }
            }
        }
    }
    return false;
}

void formulate_layout(Layout* layout) {
    // std::cout << "hello formulate_layout" << std::endl;
    // std::cout << "order: ";
    // for (int i = 0; i < layout->order.size(); i++) {
    //     std::cout << layout->order[i] << " ";
    // }
    // std::cout << std::endl;
    // std::cout << "bias: ";
    // for (int i = 0; i < layout->bias.size(); i++) {
    //     std::cout << layout->bias[i] << " ";
    // }
    // std::cout << std::endl;
    // std::cout << "flip: ";
    // for (int i = 0; i < layout->flip.size(); i++) {
    //     std::cout << layout->flip[i] << " ";
    // }
    // std::cout << std::endl;
    int height = 4;
    for (int r = 0; r < layout->single_rows.size(); r++) {
        SingleRow* single_row = layout->single_rows[r];
        for (int i = 0; i < layout->metal_matrix.size(); i++) {
            for (int j = 0; j < height; j++) {
                for (int k = 0; k < layout->metal_matrix[i][j].size(); k++) {
                    if (layout->order[r] % 2 == 0) {
                        layout->metal_matrix[i][layout->order[r] * 4 + j][k] = single_row->metal_matrix[i][j][k];
                        layout->via_matrix[i][layout->order[r] * 4 + j][k] = single_row->via_matrix[i][j][k];
                    } else {
                        layout->metal_matrix[i][layout->order[r] * 4 + 3 - j][k] = single_row->metal_matrix[i][j][k];
                        layout->via_matrix[i][layout->order[r] * 4 + 3 - j][k] = single_row->via_matrix[i][j][k];
                    }
                }
            }
        }
    }
    std::vector<std::vector<std::vector<bool>>> metal_matrix_copy;
    std::vector<std::vector<std::vector<bool>>> via_matrix_copy;
    metal_matrix_copy.resize(layout->metal_matrix.size());
    for (int i = 0; i < layout->metal_matrix.size(); ++i) {
        metal_matrix_copy[i].assign(layout->metal_matrix[0].size(), std::vector<bool>(layout->metal_matrix[0][0].size(), false));
    }
    for (int i = 0; i < metal_matrix_copy.size(); i++) {
        for (int j = 0; j < metal_matrix_copy[i].size(); j++) {
            for (int k = 0; k < metal_matrix_copy[i][j].size(); k++) {
                metal_matrix_copy[i][j][k] = false;
            }
        }
    }
    via_matrix_copy.resize(layout->via_matrix.size());
    for (int i = 0; i < layout->via_matrix.size(); ++i) {
        via_matrix_copy[i].assign(layout->via_matrix[0].size(), std::vector<bool>(layout->via_matrix[0][0].size(), false));
    }
    for (int i = 0; i < via_matrix_copy.size(); i++) {
        for (int j = 0; j < via_matrix_copy[i].size(); j++) {
            for (int k = 0; k < via_matrix_copy[i][j].size(); k++) {
                via_matrix_copy[i][j][k] = false;
            }
        }
    }
    // bias
    for (int i = 0; i < metal_matrix_copy.size(); i++) {
        for (int j = 0; j < metal_matrix_copy[i].size(); j++) {
            for (int k = 0; k < metal_matrix_copy[i][j].size(); k++) {
                if (k < layout->bias[j / 4]) {
                    metal_matrix_copy[i][j][k] = false;
                    via_matrix_copy[i][j][k] = false;
                } else {
                    metal_matrix_copy[i][j][k] = layout->metal_matrix[i][j][k - layout->bias[j / 4]];
                    via_matrix_copy[i][j][k] = layout->via_matrix[i][j][k - layout->bias[j / 4]];
                }
            }
        }
    }
    layout->metal_matrix = metal_matrix_copy;
    layout->via_matrix = via_matrix_copy;
    // flip
    for (int i = 0; i < metal_matrix_copy.size(); i++) {
        for (int j = 0; j < metal_matrix_copy[i].size(); j++) {
            if (layout->flip[j / 4] == true) {
                std::reverse(layout->via_matrix[i][j].begin(), layout->via_matrix[i][j].end());
                std::reverse(layout->metal_matrix[i][j].begin(), layout->metal_matrix[i][j].end());
            }
        }
    }

    // assign metal segament
    for (int i = 0; i < layout->metal_segment_h.size(); i = i + 2) {
        for (int j = 0; j < layout->metal_segment_h[i].size(); j++) {
            for (int k = 0; k < layout->metal_segment_h[i][j].size(); k++) {
                layout->metal_segment_h[i][j][k] = layout->metal_matrix[i][j][k] && layout->metal_matrix[i][j][k + 1];
            }
        }
    }
    for (int i = 1; i < layout->metal_segment_v.size(); i = i + 2) {
        for (int j = 0; j < layout->metal_segment_v[i].size(); j++) {
            for (int k = 0; k < layout->metal_segment_v[i][j].size(); k++) {
                layout->metal_segment_v[i][j][k] = layout->metal_matrix[i][j][k] && layout->metal_matrix[i][j + 1][k];
            }
        }
    }
    // assign geometric variable
    for (int i = 0; i < layout->metal_segment_h.size(); i = i + 2) {
        for (int j = 0; j < layout->metal_segment_h[i].size(); ++j) {
            for (int k = 0; k < layout->metal_segment_h[i][j].size(); ++k) {
                if (k == 0) {
                    layout->gL[i][j][k] = layout->metal_segment_h[i][j][k];
                } else {
                    layout->gL[i][j][k] = !layout->metal_segment_h[i][j][k - 1] && layout->metal_segment_h[i][j][k];
                }
            }
        }
    }
    for (int i = 0; i < layout->metal_segment_h.size(); i = i + 2) {
        for (int j = 0; j < layout->metal_segment_h[i].size(); ++j) {
            for (int k = 0; k < layout->metal_segment_h[i][j].size(); ++k) {
                if (k == 0) {
                    layout->gR[i][j][k] = false;
                } else {
                    layout->gR[i][j][k] = layout->metal_segment_h[i][j][k - 1] && !layout->metal_segment_h[i][j][k];
                }
            }
        }
    }
    for (int i = 1; i < layout->metal_segment_v.size(); i = i + 2) {
        for (int j = 0; j < layout->metal_segment_v[i].size(); ++j) {
            for (int k = 0; k < layout->metal_segment_v[i][j].size(); ++k) {
                if (j == 0) {
                    layout->gF[i][j][k] = layout->metal_segment_v[i][j][k];
                } else {
                    layout->gF[i][j][k] = !layout->metal_segment_h[i][j - 1][k] && layout->metal_segment_h[i][j][k];
                }
            }
        }
    }
}