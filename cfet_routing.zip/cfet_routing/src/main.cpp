#include <cuda_runtime.h>
#include <omp.h>

#include <cassert>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <sstream>
#include <unordered_map>
#include <vector>

namespace fs = std::filesystem;

#include "routing.h"
#include "z3++.h"

int main(int argc, char** argv) {
    std::cout << "Hello, World!" << std::endl;

    assert(argc == 3);

    std::string folder_name = argv[1];         // 取得資料夾名稱
    std::vector<std::ifstream*> file_streams;  // 存放檔案指標

    for (const auto& entry : fs::directory_iterator(folder_name)) {
        if (entry.path().extension() == ".planning") {              // 確保是 .txt 檔案
            std::ifstream* file = new std::ifstream(entry.path());  // 使用 new 分配記憶體
            if (file->is_open()) {
                std::cout << "成功打開：" << entry.path() << std::endl;
                file_streams.push_back(file);
            } else {
                std::cerr << "無法打開：" << entry.path() << std::endl;
                delete file;  // 如果開啟失敗，就釋放記憶體
            }
        }
    }

    // // Open the input file for reading
    // std::ifstream fin(argv[1]);
    // // Check if the input file was opened successfully
    // if (!fin) {
    //     std::cerr << "Error: Could not open input file " << argv[1] << "\n";
    //     return 1;
    // }

    // Open the output file for writing
    std::ofstream fout(argv[2]);
    // Check if the output file was opened successfully
    if (!fout) {
        std::cerr << "Error: Could not open output file " << argv[2] << "\n";
        return 1;
    }
    auto start = std::chrono::high_resolution_clock::now();

    parse_input(file_streams);

    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    std::cout << "Time taken : " << elapsed.count() << " seconds" << std::endl;
    return 0;
}
